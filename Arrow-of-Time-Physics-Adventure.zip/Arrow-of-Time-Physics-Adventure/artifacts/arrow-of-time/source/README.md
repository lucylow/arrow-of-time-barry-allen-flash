# The Arrow of Time — Physics Adventure Web App

An original, responsive educational web app built from the uploaded **TODO-ARROW OF TIME KATNISS.docx** manuscript.

## Included
- 400 individual lesson modules (`src/lessons/lesson-001.js` … `lesson-400.js`)
- Volume IV lessons 301–400 across ten advanced physics and research strands
- Four Volume IV workbenches for Lorentz transformations, radioactive decay, planetary radiative equilibrium, and relativistic kinetic energy
- A 5-challenge quiz adapted from the source's opening game
- Persistent local progress, notes, scores and theme preference
- A separate demo cohort with eight fictional learner progress records
- 22 interactive physics models across four workbenches
- Searchable/filterable curriculum is included in the lesson data and learning path
- Responsive desktop and mobile layouts

## Run in Replit
Use the managed `artifacts/arrow-of-time: web` workflow to start the app preview. Its environment supplies the port and base path required by Vite.

## Build
The artifact production build creates the static bundle in `dist/public/`.

## Notes
- Progress is stored in the browser's localStorage on the current device.
- The sample learner cohort is synthetic and never modifies personal progress.
- Physics simulators state their assumptions and are intended for learning.
- Time travel into the past, traversable wormholes and controllable time machines are not presented as established technology.
- Volume IV lessons include learning objectives, key terms, worked-example frameworks, three practice tiers, investigations, misconception checks, and exit tickets.
- The app organizes its central topics into a 400-lesson sequence and includes source-aligned introductory quiz questions.
- Expansion notes: `EXPANSION-PACK-101-200.md` and `EXPANSION-PACK-201-300.md`.
