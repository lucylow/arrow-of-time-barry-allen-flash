import React, {useEffect, useMemo, useState} from 'react';
import {lessons as baseLessons} from './lessons.js';
import {volumeFourLessons} from './lessons-volume-four.js';
import AdvancedLab from './AdvancedLab.jsx';
import FrontierLab from './FrontierLab.jsx';
import DemoCohort from './DemoCohort.jsx';
import {questions} from './gameData.js';
import {ArrowLeft, ArrowRight, BookOpen, Brain, Check, ChevronDown, CircleHelp, Clock3, Compass, Flame, Home, Menu, Moon, Play, RotateCcw, Search, Settings2, Sparkles, Sun, Target, Trophy, X} from 'lucide-react';

const lessons=[...baseLessons,...volumeFourLessons];
const KEY='arrow-time-progress-v1';
const initial=()=>{try{return JSON.parse(localStorage.getItem(KEY))||{completed:[],answers:{},notes:{},bestScore:0,theme:'dark'}}catch{return {completed:[],answers:{},notes:{},bestScore:0,theme:'dark'}}};
const fmt=(n)=>Number.isFinite(n)?n.toFixed(3).replace(/\.?0+$/,''):'—';
const curriculumUnits=[
 {start:1,end:20,range:'01–20',name:'Mechanics',description:'Motion, forces and the science of Katniss’s bow',color:'orange'},
 {start:21,end:34,range:'21–34',name:'Thermodynamics',description:'Entropy and why time has a direction',color:'red'},
 {start:35,end:60,range:'35–60',name:'Relativity',description:'Einstein, spacetime and time-travel theories',color:'purple'},
 {start:61,end:70,range:'61–70',name:'Quantum',description:'The microscopic world and quantum time',color:'blue'},
 {start:71,end:80,range:'71–80',name:'Cosmology',description:'The Big Bang and the cosmic clock',color:'teal'},
 {start:81,end:100,range:'81–100',name:'Experiments',description:'Investigations, final missions and assessment',color:'gold'},
 {start:101,end:110,range:'101–110',name:'Advanced mechanics',description:'Rotation, torque and angular momentum',color:'orange'},
 {start:111,end:120,range:'111–120',name:'Waves & optics',description:'Sound, light, interference and lenses',color:'blue'},
 {start:121,end:130,range:'121–130',name:'Electricity & magnetism I',description:'Fields, circuits and electromagnetic waves',color:'purple'},
 {start:131,end:140,range:'131–140',name:'Thermal physics I',description:'Heat transfer, gases and free energy',color:'red'},
 {start:141,end:150,range:'141–150',name:'Quantum foundations',description:'Wavefunctions, spin and entanglement',color:'teal'},
 {start:151,end:160,range:'151–160',name:'Relativity & gravity',description:'Spacetime, black holes and gravitational waves',color:'gold'},
 {start:161,end:170,range:'161–170',name:'Astronomy & cosmology',description:'Orbits, stars and cosmic evidence',color:'blue'},
 {start:171,end:180,range:'171–180',name:'Complex systems I',description:'Chaos, diffusion and information',color:'purple'},
 {start:181,end:200,range:'181–200',name:'Research studio I',description:'Uncertainty, computation and capstone',color:'teal'},
 {start:201,end:210,range:'201–210',name:'Fluids & oscillations',description:'Pressure, buoyancy and coupled motion',color:'orange'},
 {start:211,end:220,range:'211–220',name:'Wave physics & optics',description:'Acoustics, resonance and wave behavior',color:'blue'},
 {start:221,end:230,range:'221–230',name:'Electricity & magnetism II',description:'Electric fields, circuits and magnetic forces',color:'purple'},
 {start:231,end:240,range:'231–240',name:'Thermal physics II',description:'Statistical mechanics and energy flow',color:'red'},
 {start:241,end:250,range:'241–250',name:'Quantum mechanics',description:'States, measurement and quantum dynamics',color:'teal'},
 {start:251,end:260,range:'251–260',name:'Nuclear & particle physics',description:'Radioactivity and fundamental particles',color:'gold'},
 {start:261,end:270,range:'261–270',name:'Relativity & compact objects',description:'Strong gravity and dense stellar remnants',color:'purple'},
 {start:271,end:280,range:'271–280',name:'Stellar cosmology',description:'Stars, observations and cosmic evidence',color:'blue'},
 {start:281,end:290,range:'281–290',name:'Nonlinear systems & networks',description:'Complexity, information and connected systems',color:'teal'},
  {start:291,end:300,range:'291–300',name:'Research synthesis',description:'Computation, inference and experimental design',color:'gold'},
  {start:301,end:310,range:'301–310',name:'Mathematical physics',description:'Tools for modeling, scaling and interpreting equations',color:'gold'},
  {start:311,end:320,range:'311–320',name:'Classical field theory',description:'Fields, potentials, waves and conservation laws',color:'purple'},
  {start:321,end:330,range:'321–330',name:'Particle physics',description:'Fundamental particles, interactions and evidence',color:'blue'},
  {start:331,end:340,range:'331–340',name:'Nuclear physics',description:'Nuclear structure, reactions, decay and safety',color:'red'},
  {start:341,end:350,range:'341–350',name:'Advanced quantum theory',description:'Quantum states, measurement and information',color:'teal'},
  {start:351,end:360,range:'351–360',name:'General relativity',description:'Spacetime geometry, gravity and tested predictions',color:'gold'},
  {start:361,end:370,range:'361–370',name:'Astrobiology & planetary science',description:'Planetary climates, habitability and evidence',color:'blue'},
  {start:371,end:380,range:'371–380',name:'Plasma & space physics',description:'Charged particles and the space environment',color:'purple'},
  {start:381,end:390,range:'381–390',name:'Computational physics',description:'Numerical methods, error and validation',color:'teal'},
  {start:391,end:400,range:'391–400',name:'Capstone investigations',description:'Research design, evidence and scientific communication',color:'orange'}
];
function App(){
 const [progress,setProgress]=useState(initial);
 const [tab,setTab]=useState('home');
 const [lessonId,setLessonId]=useState(1);
 const [query,setQuery]=useState('');
 const [filter,setFilter]=useState('All');
 const [menu,setMenu]=useState(false);
 const [gameStep,setGameStep]=useState(0);
 const [selected,setSelected]=useState({});
 const [submitted,setSubmitted]=useState(false);
 const [speed,setSpeed]=useState(0.8);
 const [mass,setMass]=useState(1);
 const [velocity,setVelocity]=useState(20);
 const [launchSpeed,setLaunchSpeed]=useState(20);
 const [angle,setAngle]=useState(45);
 const [flightTime,setFlightTime]=useState(2);
 const [showAnswer,setShowAnswer]=useState(false);
 useEffect(()=>{localStorage.setItem(KEY,JSON.stringify(progress));document.documentElement.dataset.theme=progress.theme||'dark'},[progress]);
 const lesson=lessons[lessonId-1];
 const completed=progress.completed||[];
 const score=questions.reduce((s,q,i)=>s+(progress.answers?.[i]===q.correct?120:0),0);
  const groups=['All',...curriculumUnits.map(unit=>unit.name)];
  const category=(id)=>curriculumUnits.find(unit=>id>=unit.start&&id<=unit.end)?.name||'Other';
 const filtered=useMemo(()=>lessons.filter(l=>(filter==='All'||category(l.id)===filter)&&(`${l.title} ${l.concepts} ${l.summary}`.toLowerCase().includes(query.toLowerCase()))),[filter,query]);
 const update=(patch)=>setProgress(p=>({...p,...patch}));
 const markDone=(id)=>update({completed:[...new Set([...completed,id])]});
 const goLesson=(id)=>{setLessonId(Math.min(lessons.length,Math.max(1,id)));setTab('learn');setMenu(false);setShowAnswer(false)};
 const startGame=()=>{setTab('game');setGameStep(0);setSelected({});setSubmitted(false)};
 const answer=(i)=>setSelected(s=>({...s,[gameStep]:i}));
 const submitAnswer=()=>{const q=questions[gameStep];const a=selected[gameStep];if(a===undefined)return;const next={...(progress.answers||{}),[gameStep]:a};update({answers:next,bestScore:Math.max(progress.bestScore||0,questions.reduce((sum,x,j)=>sum+(next[j]===x.correct?120:0),0))});setSubmitted(true)};
 const nextQuestion=()=>{if(gameStep<questions.length-1){setGameStep(s=>s+1);setSubmitted(false)}else setTab('results')};
 const resetGame=()=>{update({answers:{}});setGameStep(0);setSelected({});setSubmitted(false);setTab('game')};
 const completePct=Math.round(completed.length/lessons.length*100);
 const nav=[['home','Home',Home],['learn','Learning path',BookOpen],['game','The Games',Target],['lab','Physics lab',Settings2],['progress','Progress',Trophy]];
 return <div className="app-shell">
  <aside className={`sidebar ${menu?'open':''}`}><div className="brand"><div className="brand-mark">➶</div><div><b>ARROW OF TIME</b><small>PHYSICS ADVENTURE</small></div><button className="icon-btn close-menu" onClick={()=>setMenu(false)}><X size={18}/></button></div>
   <div className="side-label">YOUR ARENA</div>{nav.map(([id,label,Icon])=><button key={id} className={`nav-item ${tab===id?'active':''}`} onClick={()=>{setTab(id);setMenu(false)}}><Icon size={18}/><span>{label}</span>{id==='learn'&&<small>{lessons.length}</small>}</button>)}
   <div className="sidebar-bottom"><div className="mini-progress"><div className="mini-row"><span>Training progress</span><b>{completePct}%</b></div><div className="progress-track"><i style={{width:completePct+'%'}}/></div><small>{completed.length} of {lessons.length} lessons completed</small></div><button className="nav-item" onClick={()=>update({theme:progress.theme==='dark'?'light':'dark'})}>{progress.theme==='dark'?<Sun size={18}/>:<Moon size={18}/>}<span>Switch appearance</span></button></div>
  </aside>
  {menu&&<div className="scrim" onClick={()=>setMenu(false)}/>}
  <main className="main">
   <header className="topbar"><button className="icon-btn mobile-menu" onClick={()=>setMenu(true)}><Menu/></button><div className="crumb">THE ARENA <span>/</span> {tab.toUpperCase()}</div><div className="top-actions"><div className="score-pill"><Sparkles size={15}/><b>{score}</b><small>PTS</small></div><div className="avatar">K</div></div></header>
   {tab==='home'&&<section className="page">
    <div className="hero"><div className="hero-copy"><div className="eyebrow"><span className="pulse"/> THE TIMELINE IS COLLAPSING</div><h1>Master the physics.<br/><em>Restore time.</em></h1><p>Enter a physics adventure where every arrow follows the laws of nature — and every choice shapes your understanding of the universe.</p><div className="hero-actions"><button className="primary-btn" onClick={()=>goLesson(1)}><Play size={17} fill="currentColor"/> Continue training</button><button className="ghost-btn" onClick={startGame}>Enter the Games <ArrowRight size={16}/></button></div><div className="hero-meta"><span><BookOpen size={14}/> {lessons.length} lessons</span><span><Clock3 size={14}/> Self-paced</span><span><Brain size={14}/> High school → intro university</span></div></div><div className="hero-art"><div className="orbit orbit-a"/><div className="orbit orbit-b"/><div className="planet"><div className="planet-ring"/></div><div className="arrow-glow">➶</div><div className="art-caption"><span>MISSION 001</span><b>THE ARROW THAT DEFIED TIME</b></div></div></div>
    <div className="section-head"><div><div className="eyebrow muted">CHOOSE YOUR NEXT MOVE</div><h2>Your training ground</h2></div><button className="text-btn" onClick={()=>setTab('learn')}>View all {lessons.length} lessons <ArrowRight size={15}/></button></div>
    <div className="feature-grid"><button className="feature-card featured" onClick={()=>goLesson(lessonId)}><div className="feature-icon orange"><BookOpen/></div><div className="feature-top"><span>LEARNING PATH</span><span className="tag">{completePct}% COMPLETE</span></div><h3>Explore the science of time</h3><p>Motion, energy, entropy, relativity, quantum physics and the cosmos.</p><div className="card-bottom"><span>{completed.length}/{lessons.length} lessons</span><ArrowRight size={17}/></div></button><button className="feature-card" onClick={startGame}><div className="feature-icon purple"><Target/></div><div className="feature-top"><span>5 CHALLENGES</span><span className="tag">UP TO 600 PTS</span></div><h3>Enter the Games</h3><p>Test your knowledge and save the timeline with five physics missions.</p><div className="card-bottom"><span>Best score: {progress.bestScore||0}/600</span><ArrowRight size={17}/></div></button><button className="feature-card" onClick={()=>setTab('lab')}><div className="feature-icon blue"><Settings2/></div><div className="feature-top"><span>INTERACTIVE TOOLS</span><span className="tag">EXPERIMENT</span></div><h3>Physics lab</h3><p>Explore motion, spacetime, decay, planetary climates, plasma and computational models.</p><div className="card-bottom"><span>22 interactive models</span><ArrowRight size={17}/></div></button></div>
    <div className="section-head"><div><div className="eyebrow muted">THE {lessons.length}-LESSON JOURNEY</div><h2>Explore the universe</h2></div></div><div className="path-grid">{curriculumUnits.map(unit=><button className="path-card" key={unit.start} onClick={()=>goLesson(unit.start)}><span className={'path-num '+unit.color}>{unit.range}</span><div><b>{unit.name}</b><p>{unit.description}</p></div><ArrowRight size={16}/></button>)}</div>
   </section>}
   {tab==='learn'&&<section className="page learn-page"><div className="learn-header"><div><div className="eyebrow muted">LEARNING PATH / {category(lesson.id).toUpperCase()}</div><h1>{lesson.title}</h1><p>{lesson.concepts}</p></div><span className="lesson-counter">{String(lesson.id).padStart(3,'0')} <i>/ {lessons.length}</i></span></div><div className="lesson-layout"><article className="lesson-content"><div className="story-banner"><span>🏹 FIELD NOTES · MISSION {String(lesson.id).padStart(3,'0')}</span><p>{lesson.mission}. The timeline is unstable. Use the physics to separate what the model predicts from what the story imagines.</p></div><h2>Physics briefing</h2><p className="lead">{lesson.summary}</p><div className="concept-box"><div className="concept-head"><Sparkles size={17}/> KEY CONCEPT</div><p>{lesson.concepts}</p></div><h2>Explore the idea</h2><p>{lesson.sourceNotes}</p><div className="equation-card"><div className="eyebrow muted">THINK LIKE A PHYSICIST</div><p>{lesson.reflection}</p></div><section className="lesson-detail-grid"><div className="detail-panel"><h2>Learning objectives</h2><ul>{lesson.learningObjectives?.map((x,i)=><li key={i}>{x}</li>)}</ul></div><div className="detail-panel"><h2>Key terms</h2>{lesson.keyTerms?.map((x,i)=><p key={i}><b>{x.term}:</b> {x.meaning}</p>)}</div><div className="detail-panel"><h2>Worked example</h2><p><b>{lesson.workedExample?.question}</b></p><ol>{lesson.workedExample?.method?.map((x,i)=><li key={i}>{x}</li>)}</ol><p>{lesson.workedExample?.answer}</p><small>{lesson.workedExample?.check}</small></div><div className="detail-panel"><h2>Practice challenges</h2>{lesson.practice?.map((x,i)=><p key={i}><b>{x.difficulty} · {x.skill}:</b> {x.prompt}</p>)}</div><div className="detail-panel"><h2>Investigation</h2><p><b>{lesson.investigation?.question}</b></p><ol>{lesson.investigation?.method?.map((x,i)=><li key={i}>{x}</li>)}</ol><small>Safety: {lesson.investigation?.safety}</small></div><div className="detail-panel"><h2>Misconception check</h2>{lesson.misconceptions?.map((x,i)=><p key={i}><b>{x.claim}</b><br/>{x.correction}</p>)}</div><div className="detail-panel"><h2>Exit ticket</h2><ol>{lesson.exitTicket?.map((x,i)=><li key={i}>{x}</li>)}</ol></div></section><div className="lesson-actions"><button className="ghost-btn" disabled={lesson.id===1} onClick={()=>goLesson(lesson.id-1)}><ArrowLeft size={16}/> Previous</button><button className="primary-btn" onClick={()=>{markDone(lesson.id);if(lesson.id<lessons.length)goLesson(lesson.id+1)}}>{completed.includes(lesson.id)?'Completed ✓':'Mark complete'} <Check size={16}/></button><button className="ghost-btn" disabled={lesson.id===lessons.length} onClick={()=>goLesson(lesson.id+1)}>Next <ArrowRight size={16}/></button></div></article><aside className="lesson-rail"><div className="rail-card"><div className="rail-title">YOUR PROGRESS</div><div className="big-progress">{completePct}<small>%</small></div><div className="progress-track"><i style={{width:completePct+'%'}}/></div><p>{completed.length} of {lessons.length} lessons completed</p></div><div className="rail-card"><div className="rail-title">JUMP TO LESSON</div><select value={lesson.id} onChange={e=>goLesson(Number(e.target.value))}>{lessons.map(l=><option key={l.id} value={l.id}>{String(l.id).padStart(3,'0')} · {l.title}</option>)}</select></div><div className="rail-card"><div className="rail-title">MISSION NOTE</div><textarea placeholder="Write a thought or question…" value={progress.notes?.[lesson.id]||''} onChange={e=>update({notes:{...(progress.notes||{}),[lesson.id]:e.target.value}})}/><small>Saved on this device</small></div></aside></div></section>}
   {tab==='game'&&<section className="page game-page"><div className="eyebrow muted">THE CAPITOL HAS SET THE TEST</div><div className="game-heading"><div><h1>The Physics Games</h1><p>Five challenges. One timeline. Every answer matters.</p></div><div className="game-total"><Trophy size={18}/><b>{score}</b><small>/ 600 PTS</small></div></div><div className="game-progress">{questions.map((q,i)=><button key={i} onClick={()=>{setGameStep(i);setSubmitted(false)}} className={`game-dot ${gameStep===i?'current':''} ${progress.answers?.[i]!==undefined?'done':''}`}>{i+1}</button>)}</div><div className="challenge-card"><div className="challenge-top"><span>CHALLENGE {gameStep+1} / 5</span><span className="points">+120 PHYSICS POINTS</span></div><div className="challenge-icon">{['🏹','⏳','🎯','🌀','🔥'][gameStep]}</div><h2>{questions[gameStep].title}</h2><p className="challenge-story">{questions[gameStep].story}</p><div className="options">{questions[gameStep].options.map((o,i)=><button key={i} disabled={submitted} onClick={()=>answer(i)} className={`option ${selected[gameStep]===i?'selected':''} ${submitted&&i===questions[gameStep].correct?'correct':''} ${submitted&&selected[gameStep]===i&&i!==questions[gameStep].correct?'incorrect':''}`}><span className="option-letter">{String.fromCharCode(65+i)}</span><span>{o}</span>{submitted&&i===questions[gameStep].correct&&<Check size={18}/>}</button>)}</div>{submitted&&<div className={`explanation ${selected[gameStep]===questions[gameStep].correct?'good':'bad'}`}><b>{selected[gameStep]===questions[gameStep].correct?'Correct — +120 points':'Not quite — learn from the result'}</b><p>{questions[gameStep].explain}</p></div>}<div className="challenge-footer">{submitted?<button className="primary-btn" onClick={nextQuestion}>{gameStep===4?'See your results':'Next challenge'} <ArrowRight size={16}/></button>:<button className="primary-btn" disabled={selected[gameStep]===undefined} onClick={submitAnswer}>Lock in answer <Check size={16}/></button>}</div></div><p className="game-footnote">Each correct answer earns 120 points. Your answers and best score are saved on this device.</p></section>}
   {tab==='results'&&<section className="page results-page"><div className="result-medal">🏆</div><div className="eyebrow muted">THE TIMELINE IS STABLE</div><h1>{score>=480?'A master of the Arrow of Time':score>=240?'A promising tribute':'Training begins here'}</h1><p>You completed all five physics challenges.</p><div className="result-score">{score}<small> / 600</small></div><div className="result-actions"><button className="primary-btn" onClick={()=>setTab('progress')}>View progress <ArrowRight size={16}/></button><button className="ghost-btn" onClick={resetGame}><RotateCcw size={16}/> Play again</button></div><div className="review-list">{questions.map((q,i)=><div key={i} className="review-row"><span>{progress.answers?.[i]===q.correct?'✓':'×'}</span><div><b>{q.title}</b><small>{progress.answers?.[i]===q.correct?'Correct':'Review this concept'}</small></div></div>)}</div></section>}
   {tab==='lab'&&<section className="page lab-page"><div className="eyebrow muted">INTERACTIVE PHYSICS TOOLS</div><h1>Physics lab</h1><p className="page-intro">Change the variables and see how the mathematical models respond. These are idealized learning models, not real archery or engineering guidance.</p><div className="lab-grid"><div className="sim-card"><div className="sim-kicker">01 / MECHANICS</div><h2>Projectile range</h2><p>Ideal launch and landing at the same height; air resistance ignored.</p><div className="range-visual"><svg viewBox="0 0 500 180" role="img" aria-label="Ideal projectile trajectory"><path d="M20 150 H480" stroke="currentColor" opacity=".25"/><path d={`M20 150 Q250 ${150-Math.min(125,launchSpeed* Math.sin(angle*Math.PI/180)*2.5)} 480 150`} fill="none" stroke="#f29b55" strokeWidth="3" strokeDasharray="7 5"/><circle cx="20" cy="150" r="5" fill="#f29b55"/></svg><span>LAUNCH</span><span>TARGET</span></div><label>Initial speed <b>{launchSpeed} m/s</b></label><input type="range" min="5" max="50" value={launchSpeed} onChange={e=>setLaunchSpeed(+e.target.value)}/><label>Launch angle <b>{angle}°</b></label><input type="range" min="5" max="85" value={angle} onChange={e=>setAngle(+e.target.value)}/><div className="sim-result"><small>THEORETICAL RANGE</small><b>{fmt(launchSpeed**2*Math.sin(2*angle*Math.PI/180)/9.81)} m</b></div></div>
   <div className="sim-card"><div className="sim-kicker">02 / ENERGY</div><h2>Kinetic energy</h2><p>Explore how mass and speed affect energy of motion.</p><label>Mass <b>{mass.toFixed(1)} kg</b></label><input type="range" min=".1" max="10" step=".1" value={mass} onChange={e=>setMass(+e.target.value)}/><label>Speed <b>{velocity} m/s</b></label><input type="range" min="0" max="60" value={velocity} onChange={e=>setVelocity(+e.target.value)}/><div className="sim-result"><small>K = ½mv²</small><b>{fmt(.5*mass*velocity**2)} J</b></div><div className="sim-note">Doubling speed quadruples kinetic energy when mass is unchanged.</div></div>
   <div className="sim-card"><div className="sim-kicker">03 / RELATIVITY</div><h2>Time dilation</h2><p>Compare elapsed time for a moving clock at a fraction of light speed.</p><label>Velocity <b>{(speed*100).toFixed(0)}% of c</b></label><input type="range" min="0" max=".99" step=".01" value={speed} onChange={e=>setSpeed(+e.target.value)}/><div className="sim-result"><small>LORENTZ FACTOR γ</small><b>{fmt(1/Math.sqrt(1-speed**2))}</b></div><div className="sim-note">If the traveller measures 1 year, an inertial frame measures approximately {(1/Math.sqrt(1-speed**2)).toFixed(2)} years between the corresponding events, under the stated inertial-frame setup.</div></div></div><AdvancedLab/><FrontierLab/><div className="lab-warning"><CircleHelp size={18}/><p><b>Model assumptions matter.</b> The projectile tool ignores drag and assumes equal launch and landing heights. The relativity tool illustrates special-relativistic time dilation and does not model acceleration or gravity.</p></div></section>}
    {tab==='progress'&&<section className="page progress-page">
     <div className="eyebrow muted">YOUR TRAINING RECORD</div><h1>Tribute progress</h1><p className="page-intro">Your journey through the physics of time, saved locally on this device.</p>
     <div className="stats-grid">
      <div className="stat-card"><BookOpen/><b>{completed.length}<small>/{lessons.length}</small></b><span>Lessons completed</span></div>
      <div className="stat-card"><Trophy/><b>{score}<small>/600</small></b><span>Current game score</span></div>
      <div className="stat-card"><Sparkles/><b>{progress.bestScore||0}<small>/600</small></b><span>Personal best</span></div>
     </div>
     <div className="section-head"><h2>Learning path</h2><span className="tag">{completePct}% COMPLETE</span></div>
     <div className="all-progress">{curriculumUnits.map(unit=>{
      const done=completed.filter(id=>id>=unit.start&&id<=unit.end).length;
      return <div className="all-progress-row" key={unit.start}>
       <div><b>{unit.name}</b><small>{done} / {unit.end-unit.start+1} lessons</small></div>
       <div className="progress-track"><i style={{width:done/(unit.end-unit.start+1)*100+'%'}}/></div>
       <button className="text-btn" onClick={()=>goLesson(unit.start)}>Open <ArrowRight size={14}/></button>
      </div>;
     })}</div>
     <button className="danger-btn" onClick={()=>{if(confirm('Reset your saved progress, answers and notes on this device?')){localStorage.removeItem(KEY);setProgress({completed:[],answers:{},notes:{},bestScore:0,theme:progress.theme})}}}>Reset my progress</button>
     <DemoCohort lessonTotal={lessons.length}/>
    </section>}
  </main>
 </div>
}
export default App;
