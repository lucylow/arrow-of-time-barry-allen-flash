import lesson400 from './lessons/lesson-400.js';

const volumeFourModules = import.meta.glob('./lessons/lesson-3*.js', {
  eager: true,
  import: 'default',
});

export const volumeFourLessons = [
  ...Object.values(volumeFourModules).filter(
    (lesson) => lesson.id >= 301 && lesson.id < 400,
  ),
  lesson400,
].sort((a, b) => a.id - b.id);
