import React, { useState } from 'react';

const SIGMA = 5.670374419e-8;
const fmt = (value, digits = 4) =>
  Number.isFinite(value)
    ? value.toLocaleString(undefined, { maximumFractionDigits: digits })
    : '—';

function Slider({ label, value, min, max, step = 1, unit = '', onChange }) {
  return (
    <label className="frontier-control">
      <span>
        {label}
        <b>{fmt(value)} {unit}</b>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
      />
    </label>
  );
}

function Readout({ label, children }) {
  return (
    <>
      <small>{label}</small>
      <b>{children}</b>
    </>
  );
}

export default function VolumeFourLab() {
  const [beta, setBeta] = useState(0.6);
  const [position, setPosition] = useState(4);
  const [time, setTime] = useState(8);

  const [initial, setInitial] = useState(1000);
  const [halfLife, setHalfLife] = useState(5);
  const [elapsed, setElapsed] = useState(12);

  const [distance, setDistance] = useState(1);
  const [albedo, setAlbedo] = useState(0.3);
  const [emissivity, setEmissivity] = useState(1);

  const [speed, setSpeed] = useState(0.8);
  const [mass, setMass] = useState(1);

  const gamma = 1 / Math.sqrt(1 - beta ** 2);
  const xPrime = gamma * (position - beta * time);
  const tPrime = gamma * (time - beta * position);
  const interval = time ** 2 - position ** 2;
  const transformedInterval = tPrime ** 2 - xPrime ** 2;

  const remaining = initial * Math.pow(0.5, elapsed / halfLife);
  const decayed = initial - remaining;

  const solarFlux = 1361 / distance ** 2;
  const equilibriumKelvin = Math.pow(
    (solarFlux * (1 - albedo)) / (4 * emissivity * SIGMA),
    0.25,
  );

  const relativisticEnergy = (1 / Math.sqrt(1 - speed ** 2) - 1) * mass * (299792458 ** 2);
  const newtonianEnergy = 0.5 * mass * (speed * 299792458) ** 2;

  return (
    <section className="advanced-lab frontier-lab volume-four-lab">
      <div className="eyebrow muted">VOLUME IV · INTERACTIVE INSTRUMENTS</div>
      <h2>Relativity, decay & planetary energy</h2>
      <p className="page-intro">
        Four compact models for tracking what changes—and what stays invariant—across
        spacetime, nuclear ensembles, planetary climates, and high-speed motion.
      </p>

      <div className="frontier-grid">
        <article className="sim-card">
          <div className="sim-kicker">16 / SPACETIME</div>
          <h2>Lorentz transformation</h2>
          <p>
            For motion along one axis: x′ = γ(x − βt), t′ = γ(t − βx), where
            γ = 1/√(1 − β²).
          </p>
          <Slider label="Relative speed, β = v/c" value={beta} min={0} max={0.95} step={0.01} onChange={setBeta} />
          <Slider label="Position, x" value={position} min={-10} max={10} step={0.1} unit="light-seconds" onChange={setPosition} />
          <Slider label="Time, t" value={time} min={-10} max={10} step={0.1} unit="seconds" onChange={setTime} />
          <div className="sim-result">
            <Readout label="LORENTZ FACTOR, γ">{fmt(gamma)}</Readout>
            <Readout label="TRANSFORMED POSITION, x′">{fmt(xPrime)} light-seconds</Readout>
            <Readout label="TRANSFORMED TIME, t′">{fmt(tPrime)} s</Readout>
            <Readout label="INTERVAL, t² − x²">{fmt(interval)} s²</Readout>
            <Readout label="TRANSFORMED INTERVAL">{fmt(transformedInterval)} s²</Readout>
          </div>
          <small>
            Coordinates use c = 1 light-second/second, so x and t share the same
            numerical units. The interval t² − x² is invariant for this boost;
            the sign convention is time-like positive.
          </small>
        </article>

        <article className="sim-card">
          <div className="sim-kicker">17 / NUCLEAR PHYSICS</div>
          <h2>Radioactive decay</h2>
          <p>N(t) = N₀ × 2<sup>−t/T½</sup>; the model gives an ensemble expectation.</p>
          <Slider label="Initial population, N₀" value={initial} min={100} max={10000} step={100} unit="nuclei" onChange={setInitial} />
          <Slider label="Half-life, T½" value={halfLife} min={0.5} max={50} step={0.5} unit="time units" onChange={setHalfLife} />
          <Slider label="Elapsed time, t" value={elapsed} min={0} max={200} step={0.5} unit="time units" onChange={setElapsed} />
          <div className="sim-result">
            <Readout label="EXPECTED REMAINING">{fmt(remaining)} nuclei</Readout>
            <Readout label="EXPECTED DECAYED">{fmt(decayed)} nuclei</Readout>
            <Readout label="FRACTION REMAINING">{fmt((remaining / initial) * 100, 2)}%</Readout>
          </div>
          <small>
            Individual decay events are stochastic: the equation predicts the
            average behavior of many identical nuclei, not the exact fate or timing
            of any one nucleus.
          </small>
        </article>

        <article className="sim-card">
          <div className="sim-kicker">18 / PLANETARY CLIMATE</div>
          <h2>Radiative equilibrium</h2>
          <p>
            S = 1361/a² W/m²; T<sub>eq</sub> = [S(1 − A)/(4εσ)]<sup>1/4</sup>.
          </p>
          <Slider label="Orbital distance, a" value={distance} min={0.3} max={10} step={0.1} unit="AU" onChange={setDistance} />
          <Slider label="Bond albedo, A" value={albedo} min={0} max={0.9} step={0.01} onChange={setAlbedo} />
          <Slider label="Emissivity, ε" value={emissivity} min={0.1} max={1} step={0.01} onChange={setEmissivity} />
          <div className="sim-result">
            <Readout label="INCIDENT SOLAR FLUX, S">{fmt(solarFlux, 2)} W/m²</Readout>
            <Readout label="EQUILIBRIUM TEMPERATURE">{fmt(equilibriumKelvin, 2)} K</Readout>
            <Readout label="EQUILIBRIUM TEMPERATURE">{fmt(equilibriumKelvin - 273.15, 2)} °C</Readout>
          </div>
          <small>
            Assumes a spherical body with even redistribution of absorbed energy,
            thermal emission over its full surface, and no greenhouse warming.
            Uses solar flux at 1 AU of 1361 W/m² and the Stefan–Boltzmann constant.
          </small>
        </article>

        <article className="sim-card">
          <div className="sim-kicker">19 / RELATIVISTIC MECHANICS</div>
          <h2>Kinetic energy comparison</h2>
          <p>
            Relativistic K = (γ − 1)mc² alongside the low-speed approximation
            K<sub>N</sub> = ½mv².
          </p>
          <Slider label="Speed, v/c" value={speed} min={0} max={0.95} step={0.01} onChange={setSpeed} />
          <Slider label="Rest mass, m" value={mass} min={0.1} max={10} step={0.1} unit="kg" onChange={setMass} />
          <div className="sim-result">
            <Readout label="LORENTZ FACTOR, γ">{fmt(1 / Math.sqrt(1 - speed ** 2))}</Readout>
            <Readout label="RELATIVISTIC K">{fmt(relativisticEnergy, 3)} J</Readout>
            <Readout label="NEWTONIAN K">{fmt(newtonianEnergy, 3)} J</Readout>
            <Readout label="RELATIVISTIC / NEWTONIAN">
              {newtonianEnergy === 0 ? 'Undefined at rest (both are zero)' : `${fmt(relativisticEnergy / newtonianEnergy, 4)}×`}
            </Readout>
          </div>
          <small>
            The Newtonian expression is a low-speed approximation and increasingly
            underestimates energy as v approaches c. Both calculations use
            c = 299,792,458 m/s and the selected rest mass.
          </small>
        </article>
      </div>
    </section>
  );
}
