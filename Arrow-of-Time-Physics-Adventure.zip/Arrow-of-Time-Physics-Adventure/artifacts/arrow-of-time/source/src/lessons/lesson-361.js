export default {
  "id": 361,
  "title": "Habitable zones and stellar energy",
  "concepts": "Astrobiology and planetary science · Habitable zones and stellar energy",
  "summary": "Estimate how stellar luminosity and orbital distance affect received energy without treating a habitable-zone boundary as a life detector.",
  "sourceNotes": "Volume IV · Astrobiology and planetary science. Estimate how stellar luminosity and orbital distance affect received energy without treating a habitable-zone boundary as a life detector. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 361: Habitable zones and stellar energy",
  "reflection": "What evidence would help you evaluate habitable zones and stellar energy, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in habitable zones and stellar energy using accurate physics language.",
    "Apply planetary energy balance, orbital context, and evidence for habitability to a clearly stated situation involving habitable zones and stellar energy.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Habitable zones and stellar energy",
      "meaning": "Estimate how stellar luminosity and orbital distance affect received energy without treating a habitable-zone boundary as a life detector."
    },
    {
      "term": "Planetary habitability",
      "meaning": "A context-dependent assessment of whether conditions could support life, not evidence that life is present."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating habitable zones and stellar energy. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with planetary energy balance, orbital context, and evidence for habitability and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to habitable zones and stellar energy, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in habitable zones and stellar energy and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply planetary energy balance, orbital context, and evidence for habitability to a new example of habitable zones and stellar energy. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for habitable zones and stellar energy. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about habitable zones and stellar energy?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in habitable zones and stellar energy must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A planet inside a star’s habitable zone must have liquid water or life at its surface.",
      "correction": "The habitable zone is a simplified orbital estimate; atmosphere, geology, clouds, rotation, and history also matter."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in habitable zones and stellar energy in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
