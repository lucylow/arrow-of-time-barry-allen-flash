export default {
  "id": 348,
  "title": "Measurement, environment, and decoherence",
  "concepts": "Advanced quantum theory · Measurement, environment, and decoherence",
  "summary": "Explain how interaction with an environment can suppress observable interference without claiming that every interpretation question is settled.",
  "sourceNotes": "Volume IV · Advanced quantum theory. Explain how interaction with an environment can suppress observable interference without claiming that every interpretation question is settled. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 348: Measurement, environment, and decoherence",
  "reflection": "What evidence would help you evaluate measurement, environment, and decoherence, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in measurement, environment, and decoherence using accurate physics language.",
    "Apply state vectors, operators, probability, and time evolution to a clearly stated situation involving measurement, environment, and decoherence.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Measurement, environment, and decoherence",
      "meaning": "Explain how interaction with an environment can suppress observable interference without claiming that every interpretation question is settled."
    },
    {
      "term": "Quantum state",
      "meaning": "A mathematical description used to predict probabilities for possible measurement outcomes."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating measurement, environment, and decoherence. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with state vectors, operators, probability, and time evolution and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to measurement, environment, and decoherence, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in measurement, environment, and decoherence and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply state vectors, operators, probability, and time evolution to a new example of measurement, environment, and decoherence. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for measurement, environment, and decoherence. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about measurement, environment, and decoherence?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in measurement, environment, and decoherence must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A quantum state always assigns a definite classical value to every observable before measurement.",
      "correction": "A state generally predicts outcome probabilities; definite outcomes and their interpretation depend on the observable and measurement context."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in measurement, environment, and decoherence in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
