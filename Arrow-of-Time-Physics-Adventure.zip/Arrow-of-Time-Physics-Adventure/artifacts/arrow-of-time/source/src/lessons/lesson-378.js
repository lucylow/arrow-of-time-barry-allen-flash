export default {
  "id": 378,
  "title": "Space weather and forecast uncertainty",
  "concepts": "Plasma and space physics · Space weather and forecast uncertainty",
  "summary": "Use solar observations and propagation models to explain why space-weather forecasts have lead times and uncertainty.",
  "sourceNotes": "Volume IV · Plasma and space physics. Use solar observations and propagation models to explain why space-weather forecasts have lead times and uncertainty. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 378: Space weather and forecast uncertainty",
  "reflection": "What evidence would help you evaluate space weather and forecast uncertainty, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in space weather and forecast uncertainty using accurate physics language.",
    "Apply charged-particle motion, collective behavior, and space-environment evidence to a clearly stated situation involving space weather and forecast uncertainty.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Space weather and forecast uncertainty",
      "meaning": "Use solar observations and propagation models to explain why space-weather forecasts have lead times and uncertainty."
    },
    {
      "term": "Plasma",
      "meaning": "An ionized gas whose charged particles can respond collectively to electromagnetic fields."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating space weather and forecast uncertainty. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with charged-particle motion, collective behavior, and space-environment evidence and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to space weather and forecast uncertainty, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in space weather and forecast uncertainty and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply charged-particle motion, collective behavior, and space-environment evidence to a new example of space weather and forecast uncertainty. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for space weather and forecast uncertainty. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about space weather and forecast uncertainty?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in space weather and forecast uncertainty must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A plasma is just a very hot gas and its particles move independently.",
      "correction": "Temperature can matter, but collective electromagnetic behavior and characteristic length and time scales define many plasma effects."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in space weather and forecast uncertainty in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
