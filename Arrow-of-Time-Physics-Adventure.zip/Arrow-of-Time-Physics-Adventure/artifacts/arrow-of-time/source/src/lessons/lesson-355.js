export default {
  "id": 355,
  "title": "Gravitational redshift and clocks",
  "concepts": "General relativity · Gravitational redshift and clocks",
  "summary": "Compare clock rates and photon frequencies in a stated gravitational setting while specifying the observer and measurement.",
  "sourceNotes": "Volume IV · General relativity. Compare clock rates and photon frequencies in a stated gravitational setting while specifying the observer and measurement. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 355: Gravitational redshift and clocks",
  "reflection": "What evidence would help you evaluate gravitational redshift and clocks, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in gravitational redshift and clocks using accurate physics language.",
    "Apply spacetime geometry, freely falling motion, and tested predictions to a clearly stated situation involving gravitational redshift and clocks.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Gravitational redshift and clocks",
      "meaning": "Compare clock rates and photon frequencies in a stated gravitational setting while specifying the observer and measurement."
    },
    {
      "term": "Spacetime interval",
      "meaning": "A geometric quantity that relates coordinate separations in spacetime under a specified metric."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating gravitational redshift and clocks. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with spacetime geometry, freely falling motion, and tested predictions and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to gravitational redshift and clocks, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in gravitational redshift and clocks and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply spacetime geometry, freely falling motion, and tested predictions to a new example of gravitational redshift and clocks. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for gravitational redshift and clocks. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about gravitational redshift and clocks?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in gravitational redshift and clocks must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "General relativity says that gravity is simply an ordinary force that pulls objects through flat space.",
      "correction": "In general relativity, gravity is modeled through spacetime geometry; Newtonian gravity remains a useful approximation in many conditions."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in gravitational redshift and clocks in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
