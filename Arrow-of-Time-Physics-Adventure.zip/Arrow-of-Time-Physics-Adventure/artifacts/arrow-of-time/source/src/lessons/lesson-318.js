export default {
  "id": 318,
  "title": "Field energy and the Poynting vector",
  "concepts": "Classical field theory · Field energy and the Poynting vector",
  "summary": "Track electromagnetic energy density and energy flow without treating a local energy-flow direction as a particle path.",
  "sourceNotes": "Volume IV · Classical field theory. Track electromagnetic energy density and energy flow without treating a local energy-flow direction as a particle path. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 318: Field energy and the Poynting vector",
  "reflection": "What evidence would help you evaluate field energy and the poynting vector, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in field energy and the poynting vector using accurate physics language.",
    "Apply field equations, boundary conditions, and local conservation to a clearly stated situation involving field energy and the poynting vector.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Field energy and the Poynting vector",
      "meaning": "Track electromagnetic energy density and energy flow without treating a local energy-flow direction as a particle path."
    },
    {
      "term": "Field",
      "meaning": "A field assigns a physical quantity to each point in space and time."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating field energy and the poynting vector. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with field equations, boundary conditions, and local conservation and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to field energy and the poynting vector, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in field energy and the poynting vector and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply field equations, boundary conditions, and local conservation to a new example of field energy and the poynting vector. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for field energy and the poynting vector. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about field energy and the poynting vector?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in field energy and the poynting vector must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A field diagram is a set of physical strings or particles occupying every drawn line.",
      "correction": "Field lines are a visual convention for direction and relative strength; they are not material tracks."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in field energy and the poynting vector in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
