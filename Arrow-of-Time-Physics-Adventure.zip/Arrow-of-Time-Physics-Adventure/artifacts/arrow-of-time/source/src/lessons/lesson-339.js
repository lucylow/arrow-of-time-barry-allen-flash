export default {
  "id": 339,
  "title": "Radiation counts and Poisson statistics",
  "concepts": "Nuclear physics · Radiation counts and Poisson statistics",
  "summary": "Use counting statistics to understand why repeated measurements of a constant source fluctuate.",
  "sourceNotes": "Volume IV · Nuclear physics. Use counting statistics to understand why repeated measurements of a constant source fluctuate. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 339: Radiation counts and Poisson statistics",
  "reflection": "What evidence would help you evaluate radiation counts and poisson statistics, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in radiation counts and poisson statistics using accurate physics language.",
    "Apply nuclear structure, decay laws, and measured energy to a clearly stated situation involving radiation counts and poisson statistics.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Radiation counts and Poisson statistics",
      "meaning": "Use counting statistics to understand why repeated measurements of a constant source fluctuate."
    },
    {
      "term": "Nuclear binding energy",
      "meaning": "The energy associated with assembling a nucleus from its separate nucleons."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating radiation counts and poisson statistics. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with nuclear structure, decay laws, and measured energy and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to radiation counts and poisson statistics, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in radiation counts and poisson statistics and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply nuclear structure, decay laws, and measured energy to a new example of radiation counts and poisson statistics. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for radiation counts and poisson statistics. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about radiation counts and poisson statistics?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in radiation counts and poisson statistics must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A decay equation predicts the exact time at which one particular nucleus will decay.",
      "correction": "Radioactive decay is probabilistic for an individual nucleus; decay laws predict populations statistically."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in radiation counts and poisson statistics in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
