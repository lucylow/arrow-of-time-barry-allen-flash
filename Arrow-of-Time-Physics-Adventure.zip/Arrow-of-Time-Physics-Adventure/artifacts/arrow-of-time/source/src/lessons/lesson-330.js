export default {
  "id": 330,
  "title": "Discovery claims and uncertainty",
  "concepts": "Particle physics · Discovery claims and uncertainty",
  "summary": "Evaluate a particle discovery claim using background models, statistical significance, systematic uncertainty, and independent checks.",
  "sourceNotes": "Volume IV · Particle physics. Evaluate a particle discovery claim using background models, statistical significance, systematic uncertainty, and independent checks. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 330: Discovery claims and uncertainty",
  "reflection": "What evidence would help you evaluate discovery claims and uncertainty, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in discovery claims and uncertainty using accurate physics language.",
    "Apply quantum numbers, interaction rules, and experimental evidence to a clearly stated situation involving discovery claims and uncertainty.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Discovery claims and uncertainty",
      "meaning": "Evaluate a particle discovery claim using background models, statistical significance, systematic uncertainty, and independent checks."
    },
    {
      "term": "Quantum number",
      "meaning": "A label for a conserved or otherwise specified property of a particle state."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating discovery claims and uncertainty. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with quantum numbers, interaction rules, and experimental evidence and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to discovery claims and uncertainty, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in discovery claims and uncertainty and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply quantum numbers, interaction rules, and experimental evidence to a new example of discovery claims and uncertainty. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for discovery claims and uncertainty. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about discovery claims and uncertainty?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in discovery claims and uncertainty must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A diagram of a particle interaction is a literal photograph of tiny objects following visible paths.",
      "correction": "Interaction diagrams are bookkeeping tools for amplitudes and quantum numbers, not images of classical trajectories."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in discovery claims and uncertainty in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
