export default {
  "id": 314,
  "title": "Circulation and Stokes’s theorem",
  "concepts": "Classical field theory · Circulation and Stokes’s theorem",
  "summary": "Connect circulation around a closed loop with the curl through a spanning surface and keep the orientation consistent.",
  "sourceNotes": "Volume IV · Classical field theory. Connect circulation around a closed loop with the curl through a spanning surface and keep the orientation consistent. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 314: Circulation and Stokes’s theorem",
  "reflection": "What evidence would help you evaluate circulation and stokes’s theorem, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in circulation and stokes’s theorem using accurate physics language.",
    "Apply field equations, boundary conditions, and local conservation to a clearly stated situation involving circulation and stokes’s theorem.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Circulation and Stokes’s theorem",
      "meaning": "Connect circulation around a closed loop with the curl through a spanning surface and keep the orientation consistent."
    },
    {
      "term": "Field",
      "meaning": "A field assigns a physical quantity to each point in space and time."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating circulation and stokes’s theorem. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with field equations, boundary conditions, and local conservation and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to circulation and stokes’s theorem, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in circulation and stokes’s theorem and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply field equations, boundary conditions, and local conservation to a new example of circulation and stokes’s theorem. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for circulation and stokes’s theorem. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about circulation and stokes’s theorem?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in circulation and stokes’s theorem must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A field diagram is a set of physical strings or particles occupying every drawn line.",
      "correction": "Field lines are a visual convention for direction and relative strength; they are not material tracks."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in circulation and stokes’s theorem in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
