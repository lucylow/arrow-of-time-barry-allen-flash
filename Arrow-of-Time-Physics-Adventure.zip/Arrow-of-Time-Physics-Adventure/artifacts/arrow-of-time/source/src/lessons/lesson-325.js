export default {
  "id": 325,
  "title": "Decay chains and particle lifetimes",
  "concepts": "Particle physics · Decay chains and particle lifetimes",
  "summary": "Follow a decay chain while distinguishing a mean lifetime, a branching fraction, and an individual random decay time.",
  "sourceNotes": "Volume IV · Particle physics. Follow a decay chain while distinguishing a mean lifetime, a branching fraction, and an individual random decay time. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 325: Decay chains and particle lifetimes",
  "reflection": "What evidence would help you evaluate decay chains and particle lifetimes, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in decay chains and particle lifetimes using accurate physics language.",
    "Apply quantum numbers, interaction rules, and experimental evidence to a clearly stated situation involving decay chains and particle lifetimes.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Decay chains and particle lifetimes",
      "meaning": "Follow a decay chain while distinguishing a mean lifetime, a branching fraction, and an individual random decay time."
    },
    {
      "term": "Quantum number",
      "meaning": "A label for a conserved or otherwise specified property of a particle state."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating decay chains and particle lifetimes. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with quantum numbers, interaction rules, and experimental evidence and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to decay chains and particle lifetimes, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in decay chains and particle lifetimes and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply quantum numbers, interaction rules, and experimental evidence to a new example of decay chains and particle lifetimes. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for decay chains and particle lifetimes. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about decay chains and particle lifetimes?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in decay chains and particle lifetimes must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A diagram of a particle interaction is a literal photograph of tiny objects following visible paths.",
      "correction": "Interaction diagrams are bookkeeping tools for amplitudes and quantum numbers, not images of classical trajectories."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in decay chains and particle lifetimes in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
