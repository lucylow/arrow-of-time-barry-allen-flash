export default {
  "id": 344,
  "title": "Spin one-half and Stern–Gerlach",
  "concepts": "Advanced quantum theory · Spin one-half and Stern–Gerlach",
  "summary": "Model spin measurements along a chosen axis and distinguish quantized outcomes from a classical spinning sphere.",
  "sourceNotes": "Volume IV · Advanced quantum theory. Model spin measurements along a chosen axis and distinguish quantized outcomes from a classical spinning sphere. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 344: Spin one-half and Stern–Gerlach",
  "reflection": "What evidence would help you evaluate spin one-half and stern–gerlach, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in spin one-half and stern–gerlach using accurate physics language.",
    "Apply state vectors, operators, probability, and time evolution to a clearly stated situation involving spin one-half and stern–gerlach.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Spin one-half and Stern–Gerlach",
      "meaning": "Model spin measurements along a chosen axis and distinguish quantized outcomes from a classical spinning sphere."
    },
    {
      "term": "Quantum state",
      "meaning": "A mathematical description used to predict probabilities for possible measurement outcomes."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating spin one-half and stern–gerlach. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with state vectors, operators, probability, and time evolution and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to spin one-half and stern–gerlach, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in spin one-half and stern–gerlach and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply state vectors, operators, probability, and time evolution to a new example of spin one-half and stern–gerlach. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for spin one-half and stern–gerlach. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about spin one-half and stern–gerlach?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in spin one-half and stern–gerlach must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A quantum state always assigns a definite classical value to every observable before measurement.",
      "correction": "A state generally predicts outcome probabilities; definite outcomes and their interpretation depend on the observable and measurement context."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in spin one-half and stern–gerlach in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
