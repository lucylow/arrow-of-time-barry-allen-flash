export default {
  "id": 383,
  "title": "Monte Carlo sampling and uncertainty",
  "concepts": "Computational physics · Monte Carlo sampling and uncertainty",
  "summary": "Estimate a quantity by repeated random sampling and relate sampling uncertainty to the number of independent trials.",
  "sourceNotes": "Volume IV · Computational physics. Estimate a quantity by repeated random sampling and relate sampling uncertainty to the number of independent trials. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 383: Monte Carlo sampling and uncertainty",
  "reflection": "What evidence would help you evaluate monte carlo sampling and uncertainty, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in monte carlo sampling and uncertainty using accurate physics language.",
    "Apply discretization, numerical error, and comparison with evidence to a clearly stated situation involving monte carlo sampling and uncertainty.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Monte Carlo sampling and uncertainty",
      "meaning": "Estimate a quantity by repeated random sampling and relate sampling uncertainty to the number of independent trials."
    },
    {
      "term": "Numerical convergence",
      "meaning": "The approach of a numerical result toward a stable value as the discretization or approximation is refined."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating monte carlo sampling and uncertainty. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with discretization, numerical error, and comparison with evidence and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to monte carlo sampling and uncertainty, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in monte carlo sampling and uncertainty and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply discretization, numerical error, and comparison with evidence to a new example of monte carlo sampling and uncertainty. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for monte carlo sampling and uncertainty. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about monte carlo sampling and uncertainty?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in monte carlo sampling and uncertainty must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A simulation that runs without an error message has been scientifically validated.",
      "correction": "A successful run only shows that software executed; numerical checks and comparison with independent evidence are still required."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in monte carlo sampling and uncertainty in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
