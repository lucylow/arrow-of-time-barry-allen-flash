export default {
  "id": 396,
  "title": "Comparing models and residual structure",
  "concepts": "Capstone investigations · Comparing models and residual structure",
  "summary": "Compare candidate models using fit, assumptions, residual patterns, and out-of-sample or independent checks.",
  "sourceNotes": "Volume IV · Capstone investigations. Compare candidate models using fit, assumptions, residual patterns, and out-of-sample or independent checks. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 396: Comparing models and residual structure",
  "reflection": "What evidence would help you evaluate comparing models and residual structure, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in comparing models and residual structure using accurate physics language.",
    "Apply testable questions, transparent methods, and evidence-based conclusions to a clearly stated situation involving comparing models and residual structure.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Comparing models and residual structure",
      "meaning": "Compare candidate models using fit, assumptions, residual patterns, and out-of-sample or independent checks."
    },
    {
      "term": "Operational definition",
      "meaning": "A precise description of how a quantity or outcome will be measured or classified."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating comparing models and residual structure. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with testable questions, transparent methods, and evidence-based conclusions and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to comparing models and residual structure, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in comparing models and residual structure and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply testable questions, transparent methods, and evidence-based conclusions to a new example of comparing models and residual structure. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for comparing models and residual structure. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about comparing models and residual structure?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in comparing models and residual structure must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A well-designed investigation must confirm its original hypothesis to be successful.",
      "correction": "A useful investigation can reject or refine a hypothesis; the quality comes from transparent methods and honest interpretation."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in comparing models and residual structure in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
