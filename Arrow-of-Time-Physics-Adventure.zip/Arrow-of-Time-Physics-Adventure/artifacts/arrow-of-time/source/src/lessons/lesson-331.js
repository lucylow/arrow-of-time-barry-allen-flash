export default {
  "id": 331,
  "title": "Nuclear mass and binding energy",
  "concepts": "Nuclear physics · Nuclear mass and binding energy",
  "summary": "Compare a nucleus’s measured mass with its separated nucleons and interpret the difference through mass-energy equivalence.",
  "sourceNotes": "Volume IV · Nuclear physics. Compare a nucleus’s measured mass with its separated nucleons and interpret the difference through mass-energy equivalence. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 331: Nuclear mass and binding energy",
  "reflection": "What evidence would help you evaluate nuclear mass and binding energy, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in nuclear mass and binding energy using accurate physics language.",
    "Apply nuclear structure, decay laws, and measured energy to a clearly stated situation involving nuclear mass and binding energy.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Nuclear mass and binding energy",
      "meaning": "Compare a nucleus’s measured mass with its separated nucleons and interpret the difference through mass-energy equivalence."
    },
    {
      "term": "Nuclear binding energy",
      "meaning": "The energy associated with assembling a nucleus from its separate nucleons."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating nuclear mass and binding energy. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with nuclear structure, decay laws, and measured energy and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to nuclear mass and binding energy, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in nuclear mass and binding energy and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply nuclear structure, decay laws, and measured energy to a new example of nuclear mass and binding energy. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for nuclear mass and binding energy. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about nuclear mass and binding energy?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in nuclear mass and binding energy must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A decay equation predicts the exact time at which one particular nucleus will decay.",
      "correction": "Radioactive decay is probabilistic for an individual nucleus; decay laws predict populations statistically."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in nuclear mass and binding energy in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
