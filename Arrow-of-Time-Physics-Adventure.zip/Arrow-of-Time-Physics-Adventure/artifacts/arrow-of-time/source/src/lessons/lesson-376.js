export default {
  "id": 376,
  "title": "Magnetic reconnection and energy release",
  "concepts": "Plasma and space physics · Magnetic reconnection and energy release",
  "summary": "Describe reconnection as a change in magnetic connectivity in a plasma and distinguish the model from a literal cutting of field lines.",
  "sourceNotes": "Volume IV · Plasma and space physics. Describe reconnection as a change in magnetic connectivity in a plasma and distinguish the model from a literal cutting of field lines. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 376: Magnetic reconnection and energy release",
  "reflection": "What evidence would help you evaluate magnetic reconnection and energy release, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in magnetic reconnection and energy release using accurate physics language.",
    "Apply charged-particle motion, collective behavior, and space-environment evidence to a clearly stated situation involving magnetic reconnection and energy release.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Magnetic reconnection and energy release",
      "meaning": "Describe reconnection as a change in magnetic connectivity in a plasma and distinguish the model from a literal cutting of field lines."
    },
    {
      "term": "Plasma",
      "meaning": "An ionized gas whose charged particles can respond collectively to electromagnetic fields."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating magnetic reconnection and energy release. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with charged-particle motion, collective behavior, and space-environment evidence and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to magnetic reconnection and energy release, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in magnetic reconnection and energy release and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply charged-particle motion, collective behavior, and space-environment evidence to a new example of magnetic reconnection and energy release. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for magnetic reconnection and energy release. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about magnetic reconnection and energy release?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in magnetic reconnection and energy release must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A plasma is just a very hot gas and its particles move independently.",
      "correction": "Temperature can matter, but collective electromagnetic behavior and characteristic length and time scales define many plasma effects."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in magnetic reconnection and energy release in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
