export default {
  "id": 390,
  "title": "Validation against independent evidence",
  "concepts": "Computational physics · Validation against independent evidence",
  "summary": "Compare a computational prediction with analytical limits or independent observations before making a physical claim.",
  "sourceNotes": "Volume IV · Computational physics. Compare a computational prediction with analytical limits or independent observations before making a physical claim. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 390: Validation against independent evidence",
  "reflection": "What evidence would help you evaluate validation against independent evidence, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in validation against independent evidence using accurate physics language.",
    "Apply discretization, numerical error, and comparison with evidence to a clearly stated situation involving validation against independent evidence.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Validation against independent evidence",
      "meaning": "Compare a computational prediction with analytical limits or independent observations before making a physical claim."
    },
    {
      "term": "Numerical convergence",
      "meaning": "The approach of a numerical result toward a stable value as the discretization or approximation is refined."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating validation against independent evidence. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with discretization, numerical error, and comparison with evidence and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to validation against independent evidence, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in validation against independent evidence and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply discretization, numerical error, and comparison with evidence to a new example of validation against independent evidence. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for validation against independent evidence. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about validation against independent evidence?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in validation against independent evidence must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A simulation that runs without an error message has been scientifically validated.",
      "correction": "A successful run only shows that software executed; numerical checks and comparison with independent evidence are still required."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in validation against independent evidence in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
