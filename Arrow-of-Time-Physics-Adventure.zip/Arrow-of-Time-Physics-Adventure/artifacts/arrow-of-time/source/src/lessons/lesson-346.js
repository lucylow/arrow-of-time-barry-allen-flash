export default {
  "id": 346,
  "title": "Density matrices and mixed states",
  "concepts": "Advanced quantum theory · Density matrices and mixed states",
  "summary": "Use a density matrix to represent statistical mixtures and compare them with coherent superpositions.",
  "sourceNotes": "Volume IV · Advanced quantum theory. Use a density matrix to represent statistical mixtures and compare them with coherent superpositions. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 346: Density matrices and mixed states",
  "reflection": "What evidence would help you evaluate density matrices and mixed states, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in density matrices and mixed states using accurate physics language.",
    "Apply state vectors, operators, probability, and time evolution to a clearly stated situation involving density matrices and mixed states.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Density matrices and mixed states",
      "meaning": "Use a density matrix to represent statistical mixtures and compare them with coherent superpositions."
    },
    {
      "term": "Quantum state",
      "meaning": "A mathematical description used to predict probabilities for possible measurement outcomes."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating density matrices and mixed states. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with state vectors, operators, probability, and time evolution and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to density matrices and mixed states, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in density matrices and mixed states and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply state vectors, operators, probability, and time evolution to a new example of density matrices and mixed states. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for density matrices and mixed states. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about density matrices and mixed states?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in density matrices and mixed states must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A quantum state always assigns a definite classical value to every observable before measurement.",
      "correction": "A state generally predicts outcome probabilities; definite outcomes and their interpretation depend on the observable and measurement context."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in density matrices and mixed states in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
