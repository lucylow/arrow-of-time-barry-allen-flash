export default {
  "id": 374,
  "title": "Solar wind and the Parker spiral",
  "concepts": "Plasma and space physics · Solar wind and the Parker spiral",
  "summary": "Explain how solar rotation and outward plasma flow shape the large-scale interplanetary magnetic field.",
  "sourceNotes": "Volume IV · Plasma and space physics. Explain how solar rotation and outward plasma flow shape the large-scale interplanetary magnetic field. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 374: Solar wind and the Parker spiral",
  "reflection": "What evidence would help you evaluate solar wind and the parker spiral, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in solar wind and the parker spiral using accurate physics language.",
    "Apply charged-particle motion, collective behavior, and space-environment evidence to a clearly stated situation involving solar wind and the parker spiral.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Solar wind and the Parker spiral",
      "meaning": "Explain how solar rotation and outward plasma flow shape the large-scale interplanetary magnetic field."
    },
    {
      "term": "Plasma",
      "meaning": "An ionized gas whose charged particles can respond collectively to electromagnetic fields."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating solar wind and the parker spiral. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with charged-particle motion, collective behavior, and space-environment evidence and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to solar wind and the parker spiral, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in solar wind and the parker spiral and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply charged-particle motion, collective behavior, and space-environment evidence to a new example of solar wind and the parker spiral. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for solar wind and the parker spiral. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about solar wind and the parker spiral?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in solar wind and the parker spiral must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A plasma is just a very hot gas and its particles move independently.",
      "correction": "Temperature can matter, but collective electromagnetic behavior and characteristic length and time scales define many plasma effects."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in solar wind and the parker spiral in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
