export default {
  "id": 304,
  "title": "Fourier series and periodic signals",
  "concepts": "Mathematical physics · Fourier series and periodic signals",
  "summary": "Represent a periodic signal as a weighted sum of harmonics and connect its coefficients to measurable waveform features.",
  "sourceNotes": "Volume IV · Mathematical physics. Represent a periodic signal as a weighted sum of harmonics and connect its coefficients to measurable waveform features. The focus is on definitions, model assumptions, evidence, and limits of interpretation.",
  "mission": "Mission 304: Fourier series and periodic signals",
  "reflection": "What evidence would help you evaluate fourier series and periodic signals, and which assumptions matter most?",
  "learningObjectives": [
    "Explain the central idea in fourier series and periodic signals using accurate physics language.",
    "Apply mathematical structure, units, and model assumptions to a clearly stated situation involving fourier series and periodic signals.",
    "Identify model assumptions and connect a prediction with evidence and uncertainty."
  ],
  "keyTerms": [
    {
      "term": "Fourier series and periodic signals",
      "meaning": "Represent a periodic signal as a weighted sum of harmonics and connect its coefficients to measurable waveform features."
    },
    {
      "term": "Dimensional consistency",
      "meaning": "A physical equation must compare quantities with compatible dimensions."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated simplification that determines when a model is expected to apply."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described limitation in a measured or inferred quantity."
    }
  ],
  "workedExample": {
    "question": "A learner is investigating fourier series and periodic signals. What should be defined before selecting a model or equation?",
    "method": [
      "Define the system, frame of reference, and physical quantity being investigated.",
      "List measured and inferred quantities with units, uncertainty, and boundary conditions.",
      "Choose a relation consistent with mathematical structure, units, and model assumptions and explain why it applies.",
      "Work symbolically first, then substitute only values expressed in compatible units.",
      "Interpret the result and identify a limitation or independent check."
    ],
    "answer": "A defensible solution states the system and assumptions, uses a relation appropriate to fourier series and periodic signals, and interprets the result within the model’s limits.",
    "check": "Which changed assumption or measurement would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea in fourier series and periodic signals and define one key term.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Use a labelled diagram, calculation, or short model to apply mathematical structure, units, and model assumptions to a new example of fourier series and periodic signals. State units and assumptions.",
      "skill": "Model application"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two explanations or model choices for fourier series and periodic signals. Identify evidence that could distinguish them and one limitation of each.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "What safe observation, dataset, or simulation could test a prediction about fourier series and periodic signals?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled public data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction before examining results.",
      "Define variables, the measurement procedure, and any comparison or control.",
      "Collect or generate a small labelled dataset and retain units and uncertainty.",
      "Graph the relevant quantities and compare the pattern with the model prediction.",
      "Discuss alternative explanations, limitations, and one useful next measurement."
    ],
    "safety": "Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "The idea in fourier series and periodic signals must produce an exact match between every model prediction and measurement.",
      "correction": "Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences."
    },
    {
      "claim": "A complicated calculation is automatically a more accurate physical model.",
      "correction": "Mathematical detail cannot compensate for unsupported assumptions, poor data, or a model used outside its domain."
    },
    {
      "claim": "A model output is itself a direct observation.",
      "correction": "A model output follows from assumptions and inputs; observations come from measurements and also require interpretation."
    }
  ],
  "exitTicket": [
    "Summarize the central idea in fourier series and periodic signals in one sentence.",
    "Name one assumption and one quantity that should be measured or checked.",
    "What additional evidence would make your conclusion stronger?"
  ]
};
