import React from 'react';
import {BookOpen, Trophy, Users} from 'lucide-react';
import {demoLearners} from './demoLearners.js';
import './DemoCohort.css';

export default function DemoCohort({lessonTotal}) {
  const avgCompletion = Math.round(
    (demoLearners.reduce((total, learner) => total + learner.completedLessons, 0) /
      demoLearners.length /
      lessonTotal) *
      100,
  );
  const avgBestScore = Math.round(
    demoLearners.reduce((total, learner) => total + learner.bestScore, 0) /
      demoLearners.length,
  );

  return (
    <section className="demo-cohort" aria-labelledby="demo-cohort-title">
      <div className="demo-cohort-heading">
        <div>
          <div className="eyebrow muted">SAMPLE COHORT · MOCK DATA</div>
          <h2 id="demo-cohort-title">Sample learner progress</h2>
          <p>
            Explore a fictional learner group. This sample never changes or
            includes your personal progress.
          </p>
        </div>
        <span className="demo-only-pill">DEMO ONLY</span>
      </div>

      <div className="stats-grid demo-summary">
        <div className="stat-card">
          <Users aria-hidden="true" />
          <b>{demoLearners.length}</b>
          <span>Sample learners</span>
        </div>
        <div className="stat-card">
          <BookOpen aria-hidden="true" />
          <b>{avgCompletion}<small>%</small></b>
          <span>Average lesson completion</span>
        </div>
        <div className="stat-card">
          <Trophy aria-hidden="true" />
          <b>{avgBestScore}<small> / 600</small></b>
          <span>Average personal best</span>
        </div>
      </div>

      <div className="demo-learner-grid">
        {demoLearners.map((learner, index) => {
          const completion = Math.round(
            (learner.completedLessons / lessonTotal) * 100,
          );
          const streak =
            learner.streakDays > 0
              ? `${learner.streakDays} day streak`
              : 'No current streak';

          return (
            <article className="demo-learner-card" key={learner.id}>
              <div className="demo-learner-heading">
                <div className="demo-learner-ident">
                  <span className="demo-learner-avatar" aria-hidden="true">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                  <div>
                    <h3>{learner.name}</h3>
                    <small>Last active {learner.lastActive.toLowerCase()}</small>
                  </div>
                </div>
                <b className="demo-completion">{completion}%</b>
              </div>

              <div
                className="demo-progress-track"
                role="progressbar"
                aria-label={`${learner.name} lesson completion`}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={completion}
              >
                <span style={{width: `${completion}%`}} />
              </div>

              <div className="demo-learner-metrics">
                <span>
                  <b>{learner.completedLessons}</b> / {lessonTotal} lessons
                </span>
                <span>
                  <b>{learner.bestScore}</b> / 600 best
                </span>
              </div>

              <div className="demo-learner-detail">
                <small>Current unit</small>
                <b>{learner.currentUnit}</b>
              </div>
              <div className="demo-learner-detail">
                <small>Activity</small>
                <b>{streak}</b>
              </div>
            </article>
          );
        })}
      </div>
      <p className="demo-data-note">
        All eight learner records and summary statistics are synthetic sample
        data, not live classroom records.
      </p>
    </section>
  );
}
