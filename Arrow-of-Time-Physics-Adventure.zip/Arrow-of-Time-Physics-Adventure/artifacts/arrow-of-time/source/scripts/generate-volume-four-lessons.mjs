import { mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const outputDir = fileURLToPath(new URL('../src/lessons/', import.meta.url));

const strands = [
  {
    name: 'Mathematical physics',
    start: 301,
    principle: 'mathematical structure, units, and model assumptions',
    commonTerm: 'Dimensional consistency',
    commonMeaning: 'A physical equation must compare quantities with compatible dimensions.',
    misconception: 'A complicated calculation is automatically a more accurate physical model.',
    correction: 'Mathematical detail cannot compensate for unsupported assumptions, poor data, or a model used outside its domain.',
    lessons: [
      ['Dimensional analysis for derived models', 'Use base dimensions to test an equation before substituting values; matching units is necessary, though not sufficient, evidence of a valid relation.'],
      ['Vectors and coordinate bases', 'Resolve a vector into components in a declared basis and distinguish a change of coordinates from a change in the physical vector.'],
      ['Eigenvalues in coupled oscillators', 'Interpret eigenvalues and eigenvectors as mode frequencies and mode shapes for a linear system near equilibrium.'],
      ['Fourier series and periodic signals', 'Represent a periodic signal as a weighted sum of harmonics and connect its coefficients to measurable waveform features.'],
      ['Differential equations and physical evolution', 'Read a differential equation together with initial conditions to understand which trajectory a model predicts.'],
      ['Probability distributions in measurement', 'Describe repeated measurements with a distribution and distinguish random scatter from a systematic offset.'],
      ['Gradient, divergence, and curl', 'Interpret spatial change, local source strength, and circulation using the gradient, divergence, and curl of fields.'],
      ['Matrix transformations and basis changes', 'Use matrices to transform components while keeping the represented physical state distinct from its coordinate description.'],
      ['Scaling and nondimensionalization', 'Build dimensionless ratios to reveal which effects can control a system and which parameters may be negligible.'],
      ['Auditing a mathematical model', 'Check domains, limiting cases, units, and uncertainty before trusting a mathematical prediction.'],
    ],
  },
  {
    name: 'Classical field theory',
    start: 311,
    principle: 'field equations, boundary conditions, and local conservation',
    commonTerm: 'Field',
    commonMeaning: 'A field assigns a physical quantity to each point in space and time.',
    misconception: 'A field diagram is a set of physical strings or particles occupying every drawn line.',
    correction: 'Field lines are a visual convention for direction and relative strength; they are not material tracks.',
    lessons: [
      ['Scalar fields and potentials', 'Map a scalar value across space and use contours to compare locations without confusing the map with the physical source.'],
      ['Potential gradients and force fields', 'Relate the spatial change of a potential to a force field, while stating the sign convention and reference level.'],
      ['Flux and Gauss’s law', 'Use symmetry and a closed surface to connect net field flux with the source enclosed by that surface.'],
      ['Circulation and Stokes’s theorem', 'Connect circulation around a closed loop with the curl through a spanning surface and keep the orientation consistent.'],
      ['Wave equations for fields', 'Identify how a field disturbance propagates from a wave equation and distinguish phase speed from energy transport.'],
      ['Superposition of field sources', 'Add field contributions from multiple sources as vectors and test the result against symmetry and limiting cases.'],
      ['Boundary conditions at interfaces', 'Apply the appropriate field boundary conditions at a material boundary and identify which quantities may be discontinuous.'],
      ['Field energy and the Poynting vector', 'Track electromagnetic energy density and energy flow without treating a local energy-flow direction as a particle path.'],
      ['Gauge potentials and observable fields', 'Explain how different potentials can represent the same observable electric and magnetic fields.'],
      ['Conservation of field energy and momentum', 'Use a conservation statement to account for energy and momentum exchanged between fields, sources, and matter.'],
    ],
  },
  {
    name: 'Particle physics',
    start: 321,
    principle: 'quantum numbers, interaction rules, and experimental evidence',
    commonTerm: 'Quantum number',
    commonMeaning: 'A label for a conserved or otherwise specified property of a particle state.',
    misconception: 'A diagram of a particle interaction is a literal photograph of tiny objects following visible paths.',
    correction: 'Interaction diagrams are bookkeeping tools for amplitudes and quantum numbers, not images of classical trajectories.',
    lessons: [
      ['The Standard Model map', 'Organize known elementary particles by their roles and interactions, while separating the model’s tested scope from open questions.'],
      ['Particle families and quantum numbers', 'Classify leptons and quarks by family and track charge and other quantum numbers in a reaction.'],
      ['Conservation laws in particle reactions', 'Check charge, energy, momentum, and relevant quantum numbers before deciding whether a proposed reaction is allowed.'],
      ['Feynman diagrams as bookkeeping', 'Read vertices and internal lines as terms in a calculation rather than as direct pictures of what a detector sees.'],
      ['Decay chains and particle lifetimes', 'Follow a decay chain while distinguishing a mean lifetime, a branching fraction, and an individual random decay time.'],
      ['Neutrino oscillations and evidence', 'Connect changing neutrino flavor probabilities with propagation and the evidence that neutrinos have nonzero mass differences.'],
      ['Quark confinement and hadrons', 'Explain why isolated color-charged quarks are not observed and how jets provide indirect evidence in high-energy collisions.'],
      ['The Higgs field and particle masses', 'Describe the Higgs mechanism at an introductory level and avoid treating it as the source of every form of mass.'],
      ['Collider energy and production thresholds', 'Use energy and momentum conservation to reason about which final states a collision can produce.'],
      ['Discovery claims and uncertainty', 'Evaluate a particle discovery claim using background models, statistical significance, systematic uncertainty, and independent checks.'],
    ],
  },
  {
    name: 'Nuclear physics',
    start: 331,
    principle: 'nuclear structure, decay laws, and measured energy',
    commonTerm: 'Nuclear binding energy',
    commonMeaning: 'The energy associated with assembling a nucleus from its separate nucleons.',
    misconception: 'A decay equation predicts the exact time at which one particular nucleus will decay.',
    correction: 'Radioactive decay is probabilistic for an individual nucleus; decay laws predict populations statistically.',
    lessons: [
      ['Nuclear mass and binding energy', 'Compare a nucleus’s measured mass with its separated nucleons and interpret the difference through mass-energy equivalence.'],
      ['The mass defect and the binding curve', 'Use mass defect to reason about nuclear stability and why energy can be released by some fission and fusion reactions.'],
      ['Alpha decay and quantum tunneling', 'Describe alpha decay as a probabilistic process involving a barrier and distinguish a model probability from a guaranteed event.'],
      ['Beta decay and the weak interaction', 'Balance charge and lepton number in beta processes and identify the role of the neutrino in energy and momentum accounting.'],
      ['Gamma transitions and nuclear levels', 'Relate gamma-ray energies to differences between nuclear energy levels without assuming every transition has the same energy.'],
      ['Fission, energy release, and chain reactions', 'Track energy and neutron balance in a fission model and distinguish a controlled chain reaction from an uncontrolled one.'],
      ['Fusion and stellar energy production', 'Explain how fusion can release energy for suitable nuclei and why temperature, density, and confinement affect reaction rates.'],
      ['Nuclear cross sections and reaction probability', 'Interpret a cross section as a measure of interaction likelihood under stated conditions, not as a literal hard-edged target area.'],
      ['Radiation counts and Poisson statistics', 'Use counting statistics to understand why repeated measurements of a constant source fluctuate.'],
      ['Radiation dose, shielding, and safety', 'Distinguish activity, absorbed dose, and biological dose, and use established safety guidance rather than improvised experiments.'],
    ],
  },
  {
    name: 'Advanced quantum theory',
    start: 341,
    principle: 'state vectors, operators, probability, and time evolution',
    commonTerm: 'Quantum state',
    commonMeaning: 'A mathematical description used to predict probabilities for possible measurement outcomes.',
    misconception: 'A quantum state always assigns a definite classical value to every observable before measurement.',
    correction: 'A state generally predicts outcome probabilities; definite outcomes and their interpretation depend on the observable and measurement context.',
    lessons: [
      ['State vectors and Hilbert space', 'Use state vectors and inner products to represent quantum states and calculate probabilities for specified measurements.'],
      ['Operators and observables', 'Connect Hermitian operators with measurable quantities and interpret eigenvalues as possible measurement outcomes.'],
      ['Commutators and uncertainty', 'Use noncommuting observables to understand why some pairs cannot have arbitrarily small simultaneous uncertainties.'],
      ['Spin one-half and Stern–Gerlach', 'Model spin measurements along a chosen axis and distinguish quantized outcomes from a classical spinning sphere.'],
      ['Time evolution and the Schrödinger equation', 'Describe how a closed system’s state changes under a Hamiltonian and state the assumptions behind that evolution.'],
      ['Density matrices and mixed states', 'Use a density matrix to represent statistical mixtures and compare them with coherent superpositions.'],
      ['Entanglement and correlations', 'Identify correlations that cannot be represented as independent local states without implying controllable faster-than-light signals.'],
      ['Measurement, environment, and decoherence', 'Explain how interaction with an environment can suppress observable interference without claiming that every interpretation question is settled.'],
      ['Perturbation theory and small corrections', 'Estimate how a small added interaction changes an energy level and check when the approximation remains useful.'],
      ['Quantum information and gates', 'Track a simple quantum state through reversible gates and distinguish a logical operation from a measurement.'],
    ],
  },
  {
    name: 'General relativity',
    start: 351,
    principle: 'spacetime geometry, freely falling motion, and tested predictions',
    commonTerm: 'Spacetime interval',
    commonMeaning: 'A geometric quantity that relates coordinate separations in spacetime under a specified metric.',
    misconception: 'General relativity says that gravity is simply an ordinary force that pulls objects through flat space.',
    correction: 'In general relativity, gravity is modeled through spacetime geometry; Newtonian gravity remains a useful approximation in many conditions.',
    lessons: [
      ['The equivalence principle', 'Compare local freely falling frames with inertial motion and state why the equivalence principle is local rather than universal.'],
      ['Metrics and proper time', 'Use a metric to relate coordinate descriptions to measured spacetime intervals and proper time.'],
      ['Geodesics and free fall', 'Interpret a geodesic as locally straight motion in curved spacetime rather than as a path chosen by a force in flat space.'],
      ['Schwarzschild radius and event horizons', 'Relate the Schwarzschild radius to a nonrotating spherical mass and distinguish an event horizon from a material surface.'],
      ['Gravitational redshift and clocks', 'Compare clock rates and photon frequencies in a stated gravitational setting while specifying the observer and measurement.'],
      ['Tidal forces and geodesic deviation', 'Explain how nearby freely falling paths can separate or converge and why tidal effects cannot be removed across an extended region.'],
      ['Gravitational waves and detectors', 'Describe gravitational waves as changing spacetime strain and interpret detector signals with noise and calibration in mind.'],
      ['Cosmic expansion and the Friedmann picture', 'Interpret expansion through scale factor and density components without mistaking it for galaxies moving through a central point.'],
      ['Gravitational lensing as a mass probe', 'Use light deflection to infer projected mass while acknowledging degeneracies in lens models and source geometry.'],
      ['Testing general relativity and its limits', 'Compare a prediction with observations and separate a successful test from proof that a theory is complete in every regime.'],
    ],
  },
  {
    name: 'Astrobiology and planetary science',
    start: 361,
    principle: 'planetary energy balance, orbital context, and evidence for habitability',
    commonTerm: 'Planetary habitability',
    commonMeaning: 'A context-dependent assessment of whether conditions could support life, not evidence that life is present.',
    misconception: 'A planet inside a star’s habitable zone must have liquid water or life at its surface.',
    correction: 'The habitable zone is a simplified orbital estimate; atmosphere, geology, clouds, rotation, and history also matter.',
    lessons: [
      ['Habitable zones and stellar energy', 'Estimate how stellar luminosity and orbital distance affect received energy without treating a habitable-zone boundary as a life detector.'],
      ['Planetary radiative equilibrium', 'Estimate an effective temperature from absorbed starlight and thermal emission under a stated global-average model.'],
      ['Atmospheres and greenhouse energy budgets', 'Trace incoming and outgoing energy in a simple atmosphere and distinguish a greenhouse mechanism from a complete climate model.'],
      ['Orbital cycles and climate variation', 'Relate changes in orbital geometry to seasonality and long-term insolation while separating correlation from a full climate explanation.'],
      ['Exoplanet transits and planet size', 'Use transit depth to estimate a planet-to-star radius ratio and identify the geometric and observational selection effects.'],
      ['Radial velocity and orbital mass', 'Interpret a star’s line-of-sight motion to constrain an orbit and minimum planet mass.'],
      ['Magnetic fields and atmospheric escape', 'Compare atmospheric escape mechanisms and avoid assuming that a magnetic field alone guarantees atmospheric retention.'],
      ['Comparative climates of Mars and Venus', 'Use measured atmosphere and surface data to compare planetary climate histories rather than relying on simple Earth analogies.'],
      ['Biosignatures and false positives', 'Evaluate a possible biosignature alongside nonbiological pathways, context, and independent measurements.'],
      ['Habitability as a chain of evidence', 'Build a transparent argument from planetary conditions, measurable evidence, and uncertainty without claiming life from habitability alone.'],
    ],
  },
  {
    name: 'Plasma and space physics',
    start: 371,
    principle: 'charged-particle motion, collective behavior, and space-environment evidence',
    commonTerm: 'Plasma',
    commonMeaning: 'An ionized gas whose charged particles can respond collectively to electromagnetic fields.',
    misconception: 'A plasma is just a very hot gas and its particles move independently.',
    correction: 'Temperature can matter, but collective electromagnetic behavior and characteristic length and time scales define many plasma effects.',
    lessons: [
      ['Debye shielding and plasma length scales', 'Explain how mobile charges reduce a static electric potential over a characteristic Debye length.'],
      ['Plasma frequency and collective response', 'Interpret plasma frequency as a characteristic collective oscillation rate under an idealized model.'],
      ['Gyromotion and the Larmor radius', 'Relate charged-particle gyration to charge, mass, speed, and magnetic-field strength while specifying perpendicular velocity.'],
      ['Solar wind and the Parker spiral', 'Explain how solar rotation and outward plasma flow shape the large-scale interplanetary magnetic field.'],
      ['Magnetospheres and auroral particles', 'Connect solar-wind interactions, magnetic geometry, and energetic-particle precipitation to auroral emission.'],
      ['Magnetic reconnection and energy release', 'Describe reconnection as a change in magnetic connectivity in a plasma and distinguish the model from a literal cutting of field lines.'],
      ['Alfvén waves and magnetic tension', 'Relate transverse disturbances in a magnetized plasma to magnetic tension and the Alfvén speed.'],
      ['Space weather and forecast uncertainty', 'Use solar observations and propagation models to explain why space-weather forecasts have lead times and uncertainty.'],
      ['Spacecraft charging and plasma interaction', 'Identify how plasma conditions can charge a spacecraft and why grounding and mission-specific engineering controls matter.'],
      ['Plasma diagnostics and inferred quantities', 'Compare diagnostic measurements and explain how instrument response and model assumptions affect inferred plasma properties.'],
    ],
  },
  {
    name: 'Computational physics',
    start: 381,
    principle: 'discretization, numerical error, and comparison with evidence',
    commonTerm: 'Numerical convergence',
    commonMeaning: 'The approach of a numerical result toward a stable value as the discretization or approximation is refined.',
    misconception: 'A simulation that runs without an error message has been scientifically validated.',
    correction: 'A successful run only shows that software executed; numerical checks and comparison with independent evidence are still required.',
    lessons: [
      ['Finite differences and spatial grids', 'Approximate derivatives on a grid and examine how grid spacing affects truncation error.'],
      ['Numerical integration and accumulated error', 'Approximate a definite integral with finite samples and compare accuracy as resolution changes.'],
      ['Monte Carlo sampling and uncertainty', 'Estimate a quantity by repeated random sampling and relate sampling uncertainty to the number of independent trials.'],
      ['Stability, step size, and numerical artifacts', 'Recognize when a numerical method amplifies errors and distinguish a computational artifact from physical instability.'],
      ['Root finding and physical solutions', 'Find a numerical root with a bracketed or iterative method and check that it satisfies the original equation.'],
      ['ODE simulation and conservation checks', 'Integrate a time-dependent model and monitor conserved quantities to detect accumulated numerical drift.'],
      ['Grid convergence and resolution studies', 'Repeat a computation at progressively finer resolution and use the trend to assess discretization effects.'],
      ['Data fitting, residuals, and overfitting', 'Compare residual patterns and model complexity to separate explanatory fit from overfitting.'],
      ['Reproducibility and computational tests', 'Record code, parameters, and random seeds where appropriate, then use small tests to catch regressions.'],
      ['Validation against independent evidence', 'Compare a computational prediction with analytical limits or independent observations before making a physical claim.'],
    ],
  },
  {
    name: 'Capstone investigations',
    start: 391,
    principle: 'testable questions, transparent methods, and evidence-based conclusions',
    commonTerm: 'Operational definition',
    commonMeaning: 'A precise description of how a quantity or outcome will be measured or classified.',
    misconception: 'A well-designed investigation must confirm its original hypothesis to be successful.',
    correction: 'A useful investigation can reject or refine a hypothesis; the quality comes from transparent methods and honest interpretation.',
    lessons: [
      ['From broad interest to research question', 'Turn a broad physics interest into a bounded question that can be addressed with available observations or a model.'],
      ['Operationalizing variables and outcomes', 'Define measurable variables so another learner can apply the same procedure and interpret the result.'],
      ['Controls, comparison groups, and design', 'Choose comparisons and controls that help isolate an effect without confusing control with an absence of all variation.'],
      ['Calibration and an uncertainty budget', 'Track instrument calibration, repeatability, and major uncertainty contributions before interpreting a final result.'],
      ['Visualizing data without distortion', 'Choose axes, scales, units, and uncertainty displays that reveal patterns without overstating them.'],
      ['Comparing models and residual structure', 'Compare candidate models using fit, assumptions, residual patterns, and out-of-sample or independent checks.'],
      ['Reproducibility, notebooks, and versioning', 'Record procedures, data provenance, parameters, and code versions so another person can reproduce the analysis.'],
      ['Peer critique and evidence quality', 'Review whether evidence supports a claim and distinguish a specific critique from a personal judgment.'],
      ['Communicating limitations and uncertainty', 'State what a result does and does not establish, including plausible alternatives and sources of uncertainty.'],
      ['Final synthesis: the arrow of time', 'Connect physical models of change and temporal asymmetry while distinguishing established results from open questions.'],
    ],
  },
];

const commonMaterials = [
  'Notebook or digital lab journal',
  'Calculator or spreadsheet',
  'Clearly labelled public data or a safe simulation',
  'Graph paper or plotting software',
];

function makeLesson(strand, lesson, index) {
  const id = strand.start + index;
  const [title, focus] = lesson;
  const mission = `Mission ${String(id).padStart(3, '0')}: ${title}`;

  return {
    id,
    title,
    concepts: `${strand.name} · ${title}`,
    summary: focus,
    sourceNotes: `Volume IV · ${strand.name}. ${focus} The focus is on definitions, model assumptions, evidence, and limits of interpretation.`,
    mission,
    reflection: `What evidence would help you evaluate ${title.toLowerCase()}, and which assumptions matter most?`,
    learningObjectives: [
      `Explain the central idea in ${title.toLowerCase()} using accurate physics language.`,
      `Apply ${strand.principle} to a clearly stated situation involving ${title.toLowerCase()}.`,
      'Identify model assumptions and connect a prediction with evidence and uncertainty.',
    ],
    keyTerms: [
      { term: title, meaning: focus },
      { term: strand.commonTerm, meaning: strand.commonMeaning },
      { term: 'Model assumption', meaning: 'A stated simplification that determines when a model is expected to apply.' },
      { term: 'Uncertainty', meaning: 'A quantified or described limitation in a measured or inferred quantity.' },
    ],
    workedExample: {
      question: `A learner is investigating ${title.toLowerCase()}. What should be defined before selecting a model or equation?`,
      method: [
        'Define the system, frame of reference, and physical quantity being investigated.',
        'List measured and inferred quantities with units, uncertainty, and boundary conditions.',
        `Choose a relation consistent with ${strand.principle} and explain why it applies.`,
        'Work symbolically first, then substitute only values expressed in compatible units.',
        'Interpret the result and identify a limitation or independent check.',
      ],
      answer: `A defensible solution states the system and assumptions, uses a relation appropriate to ${title.toLowerCase()}, and interprets the result within the model’s limits.`,
      check: 'Which changed assumption or measurement would most affect the conclusion?',
    },
    practice: [
      {
        difficulty: 'Foundation',
        prompt: `Explain the central idea in ${title.toLowerCase()} and define one key term.`,
        skill: 'Conceptual understanding',
      },
      {
        difficulty: 'Application',
        prompt: `Use a labelled diagram, calculation, or short model to apply ${strand.principle} to a new example of ${title.toLowerCase()}. State units and assumptions.`,
        skill: 'Model application',
      },
      {
        difficulty: 'Extension',
        prompt: `Compare two explanations or model choices for ${title.toLowerCase()}. Identify evidence that could distinguish them and one limitation of each.`,
        skill: 'Evaluation and synthesis',
      },
    ],
    investigation: {
      question: `What safe observation, dataset, or simulation could test a prediction about ${title.toLowerCase()}?`,
      materials: commonMaterials,
      method: [
        'Write a testable question and prediction before examining results.',
        'Define variables, the measurement procedure, and any comparison or control.',
        'Collect or generate a small labelled dataset and retain units and uncertainty.',
        'Graph the relevant quantities and compare the pattern with the model prediction.',
        'Discuss alternative explanations, limitations, and one useful next measurement.',
      ],
      safety: 'Use simulations or established public datasets for hazardous or inaccessible phenomena. Do not handle radioactive sources, high voltage, lasers, pressure vessels, extreme temperatures, or high-speed machinery.',
    },
    misconceptions: [
      {
        claim: `The idea in ${title.toLowerCase()} must produce an exact match between every model prediction and measurement.`,
        correction: 'Measurements include uncertainty, and models omit effects; compare within stated uncertainty and investigate systematic differences.',
      },
      {
        claim: strand.misconception,
        correction: strand.correction,
      },
      {
        claim: 'A model output is itself a direct observation.',
        correction: 'A model output follows from assumptions and inputs; observations come from measurements and also require interpretation.',
      },
    ],
    exitTicket: [
      `Summarize the central idea in ${title.toLowerCase()} in one sentence.`,
      'Name one assumption and one quantity that should be measured or checked.',
      'What additional evidence would make your conclusion stronger?',
    ],
  };
}

await mkdir(outputDir, { recursive: true });

for (const strand of strands) {
  if (strand.lessons.length !== 10) {
    throw new Error(`${strand.name} must contain exactly 10 lessons.`);
  }

  for (const [index, lesson] of strand.lessons.entries()) {
    const record = makeLesson(strand, lesson, index);
    const filename = `lesson-${String(record.id).padStart(3, '0')}.js`;
    await writeFile(
      path.join(outputDir, filename),
      `export default ${JSON.stringify(record, null, 2)};\n`,
    );
  }
}

console.log(`Generated ${strands.length * 10} Volume IV lessons in ${outputDir}.`);
