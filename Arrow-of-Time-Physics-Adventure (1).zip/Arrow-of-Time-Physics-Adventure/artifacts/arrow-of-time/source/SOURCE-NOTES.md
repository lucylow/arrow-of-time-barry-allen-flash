# Source alignment

Primary source: `TODO-ARROW OF TIME KATNISS.docx` (uploaded by the user).

The source frames the project as a Katniss-led physics adventure about restoring a collapsing timeline. Its opening five game levels cover:
1. Why an arrow does not spontaneously reverse (energy dissipation and entropy).
2. Why shattered glass does not naturally reassemble (statistical improbability).
3. Horizontal projectile motion (20 m/s for 2 s gives 40 m).
4. Microscopic time-reversal symmetry versus macroscopic thermodynamic direction.
5. Memory formation and the thermodynamic arrow.

The 300-lesson curriculum extends those domains with advanced mechanics, waves and optics, electromagnetism, thermal and statistical physics, quantum and nuclear physics, relativity, cosmology, complex systems, and research synthesis. Speculative time-travel plot elements remain distinct from experimentally established physics.
