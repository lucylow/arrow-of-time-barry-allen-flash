# Developer guide

## Application architecture
The app is a Vite + React single-page application. Each of the 300 lessons is a standalone ES module under `src/lessons/`. `src/lessons.js` statically imports the modules so the browser bundle remains deterministic and easy to inspect.

## Lesson data contract
Every lesson exports an object with:
- `id`, `title`, `concepts`, `summary`
- `sourceNotes`, `mission`, `reflection`
- `learningObjectives`
- `keyTerms`
- `workedExample`
- `practice`
- `investigation`
- `misconceptions`
- `exitTicket`

The learning path surfaces the full lesson sequence, including worked examples, practice, investigations, misconception checks and exit tickets.

## State model
The `arrow-time-progress-v1` localStorage key stores:
- completed lesson IDs
- quiz answer selections
- best quiz score
- per-lesson notes
- theme selection

State updates are centralized through the `update` helper in `App.jsx`.

## Main views
- Home: mission introduction, topic map and entry points
- Learning path: lesson content, lesson navigation, progress and notes
- The Games: five source-aligned multiple-choice challenges with explanations
- Results: score and question review
- Physics lab: three core simulators, ten advanced models and five frontier models
- Progress: completion summary and reset control

## Extending the project
1. Add or edit lesson objects under `src/lessons/`.
2. Keep lesson IDs unique and sequential.
3. Update `src/lessons.js` when adding or removing lesson modules; keep IDs sequential.
4. Keep the quiz answer key in `src/gameData.js`.
5. Use explicit assumptions in every new simulator.
6. Run `npm run build` after code changes.

## Volume III
Lessons 201–300 extend the curriculum into fluids, wave physics, thermal and statistical mechanics, quantum and nuclear physics, compact objects, cosmology, nonlinear systems, computation and research synthesis. `FrontierLab.jsx` adds five state-driven models to the Physics Lab.

## Quality and scientific communication
Distinguish idealized equations from real-world systems. State whether air resistance is ignored, whether heights are equal, and which observer or reference frame is used. Treat backward time travel and traversable wormholes as speculative rather than established technology.
