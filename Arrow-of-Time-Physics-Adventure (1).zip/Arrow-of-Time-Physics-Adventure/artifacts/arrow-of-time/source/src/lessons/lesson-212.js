export default {
  "id": 212,
  "title": "Standing sound waves",
  "concepts": "Resonant air columns",
  "summary": "Boundary conditions determine allowed wavelengths in pipes and resonant cavities.",
  "sourceNotes": "Volume III, frontier physics sequence. Boundary conditions determine allowed wavelengths in pipes and resonant cavities. The focus is on definitions, model assumptions, evidence and limits of interpretation.",
  "mission": "Mission 212: investigate Standing sound waves",
  "reflection": "What does standing sound waves reveal about physical change, measurement or the arrow of time?",
  "learningObjectives": [
    "Describe standing sound waves using accurate physics terminology.",
    "Explain how resonant air columns connects to conservation laws, measurement or the evolution of a physical system.",
    "State the assumptions and limits of a model used to interpret evidence."
  ],
  "keyTerms": [
    {
      "term": "Standing sound waves",
      "meaning": "Boundary conditions determine allowed wavelengths in pipes and resonant cavities."
    },
    {
      "term": "System boundary",
      "meaning": "The chosen separation between the physical system and its surroundings."
    },
    {
      "term": "Model assumption",
      "meaning": "A simplifying condition that makes a calculation or explanation possible."
    },
    {
      "term": "Uncertainty",
      "meaning": "A range or distribution expressing limitations in measured or inferred quantities."
    }
  ],
  "workedExample": {
    "question": "Consider a system involving standing sound waves. Identify its boundary, relevant variables and governing assumptions before selecting an equation.",
    "method": [
      "Define the system and the physical quantity being investigated.",
      "List known values, units, boundary conditions and assumptions.",
      "Choose a governing principle and explain why it applies.",
      "Calculate or reason step by step, checking units and limiting cases.",
      "Interpret the result and identify at least one limitation."
    ],
    "answer": "Boundary conditions determine allowed wavelengths in pipes and resonant cavities.",
    "check": "Which assumption, if changed, would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Define standing sound waves and describe one physical example.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Apply resonant air columns to a worked scenario. State variables, units and assumptions.",
      "skill": "Quantitative and qualitative reasoning"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two models or explanations of standing sound waves. Identify what evidence would distinguish them.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "How would you test a claim about standing sound waves using observations or a clearly stated model?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled sample data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction.",
      "Define the system, variables and measurement procedure.",
      "Collect or generate a small dataset and record units.",
      "Graph the relevant quantities and compare with a model.",
      "Discuss uncertainty, alternative explanations and a next experiment."
    ],
    "safety": "Use simulations or safe classroom demonstrations. Do not work with hazardous radiation, high voltage, pressure vessels, lasers, extreme temperatures or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "A single equation completely describes every situation involving standing sound waves.",
      "correction": "Equations apply under stated assumptions; real systems may require additional effects or a different model."
    },
    {
      "claim": "A model prediction is the same thing as a direct observation.",
      "correction": "Predictions are consequences of assumptions; observations are measurements with uncertainty."
    },
    {
      "claim": "A small numerical uncertainty guarantees that a model is correct.",
      "correction": "Measurement precision does not eliminate systematic error, missing physics or model bias."
    }
  ],
  "exitTicket": [
    "State the central idea of standing sound waves in one sentence.",
    "Name one assumption in the model you used.",
    "What additional evidence would strengthen your conclusion?"
  ]
};
