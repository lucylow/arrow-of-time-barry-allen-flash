export default {
  "id": 166,
  "title": "Hertzsprung–Russell diagram",
  "concepts": "Astronomy and Cosmology",
  "summary": "A star’s luminosity and surface temperature reveal stages of stellar evolution.",
  "sourceNotes": "Orbits, stars, expansion and cosmic evidence. A star’s luminosity and surface temperature reveal stages of stellar evolution. The mathematical relationship is L = 4πR²σT⁴. Interpret it only with its stated assumptions and appropriate units. Radius can be inferred when luminosity and effective temperature are known.",
  "mission": "Mission 166: Hertzsprung–Russell diagram",
  "reflection": "How does hertzsprung–russell diagram help Katniss distinguish a physical prediction from a time-machine story device?",
  "learningObjectives": [
    "Describe the central idea of hertzsprung–russell diagram using accurate physics language.",
    "Apply L = 4πR²σT⁴ to a clearly defined physical situation.",
    "Identify assumptions, relevant evidence and at least one limitation of the model."
  ],
  "keyTerms": [
    {
      "term": "Hertzsprung–Russell diagram",
      "meaning": "A star’s luminosity and surface temperature reveal stages of stellar evolution."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated condition that defines the range where a simplified physical model is useful."
    },
    {
      "term": "Evidence",
      "meaning": "An observation or measurement that can be compared with a prediction."
    },
    {
      "term": "Limitation",
      "meaning": "A feature omitted or idealized that may matter in a more realistic system."
    }
  ],
  "workedExample": {
    "question": "Use hertzsprung–russell diagram to interpret this example: Radius can be inferred when luminosity and effective temperature are known.",
    "method": [
      "Define the system and identify the relevant physical quantities.",
      "Write the governing relationship and define every symbol.",
      "Convert supplied values to consistent SI units.",
      "Substitute values and show intermediate steps.",
      "Check dimensions, limiting cases and physical plausibility."
    ],
    "answer": "Radius can be inferred when luminosity and effective temperature are known.",
    "check": "Which assumption is most important, and how could you test whether it is reasonable?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain hertzsprung–russell diagram in your own words and identify its central quantity.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Create a labelled diagram or data table that could test this relationship: L = 4πR²σT⁴.",
      "skill": "Scientific representation"
    },
    {
      "difficulty": "Extension",
      "prompt": "Change one model assumption. Predict which part of the result changes and justify your reasoning.",
      "skill": "Model evaluation"
    }
  ],
  "investigation": {
    "question": "What observable evidence could test a prediction involving hertzsprung–russell diagram?",
    "materials": [
      "Notebook and pencil",
      "Calculator or spreadsheet",
      "Timer or measuring tool where appropriate",
      "A safe classroom-scale demonstration or numerical model"
    ],
    "method": [
      "State a testable prediction before collecting data.",
      "Identify independent, dependent and controlled variables.",
      "Record repeated observations with units and uncertainty.",
      "Compare the data with the model and inspect residual differences.",
      "Explain limitations and propose one improvement."
    ],
    "safety": "Use only safe, low-energy classroom demonstrations. Do not use real bows, sharp arrows, high-speed projectiles, open flames, high voltage, boiling liquids or improvised pressure vessels."
  },
  "misconceptions": [
    {
      "claim": "A mathematical model is an exact description of every physical situation.",
      "correction": "Every model has assumptions and a domain of validity; compare it with observations."
    },
    {
      "claim": "A correlation automatically establishes a causal mechanism.",
      "correction": "Consider alternative explanations, controls and independent evidence."
    },
    {
      "claim": "A fictional time machine demonstrates that the proposed process is physically possible.",
      "correction": "Separate narrative devices from experimentally supported physics and mathematical models."
    }
  ],
  "exitTicket": [
    "State the central principle behind hertzsprung–russell diagram.",
    "Name one assumption in the worked example.",
    "Describe one measurement that could challenge the model."
  ]
};
