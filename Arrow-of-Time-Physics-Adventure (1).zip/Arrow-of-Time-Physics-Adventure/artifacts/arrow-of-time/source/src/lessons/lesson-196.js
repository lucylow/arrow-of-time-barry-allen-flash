export default {
  "id": 196,
  "title": "Entropy production",
  "concepts": "Research Studio and Capstone",
  "summary": "Irreversible processes generate entropy in the universe even when a subsystem loses entropy.",
  "sourceNotes": "Final research studio. Irreversible processes generate entropy in the universe even when a subsystem loses entropy. Governing idea: Sgen ≥ 0. Heat flowing spontaneously from hot to cold generates total entropy.",
  "mission": "Mission 196: Entropy production",
  "reflection": "How could entropy production strengthen or qualify a claim about the arrow of time?",
  "learningObjectives": [
    "Explain entropy production with accurate terminology.",
    "Interpret the relationship Sgen ≥ 0.",
    "Distinguish evidence, assumptions and inference."
  ],
  "keyTerms": [
    {
      "term": "Entropy production",
      "meaning": "Irreversible processes generate entropy in the universe even when a subsystem loses entropy."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described range of plausible values or interpretations."
    },
    {
      "term": "Reproducibility",
      "meaning": "The ability for another person to repeat an analysis from documented materials."
    },
    {
      "term": "Falsifiability",
      "meaning": "A claim is testable when evidence could in principle show it to be wrong."
    }
  ],
  "workedExample": {
    "question": "Heat flowing spontaneously from hot to cold generates total entropy.",
    "method": [
      "State the question and define the system or hypothesis.",
      "Identify the data and assumptions required.",
      "Choose an appropriate method and explain why it fits.",
      "Carry out the analysis with units and transparent steps.",
      "Report uncertainty, limitations and a possible alternative explanation."
    ],
    "answer": "Heat flowing spontaneously from hot to cold generates total entropy.",
    "check": "What new observation would cause you to revise the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Define entropy production and give one example.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Apply the principle Sgen ≥ 0 to a small hypothetical dataset or scenario.",
      "skill": "Analysis"
    },
    {
      "difficulty": "Extension",
      "prompt": "Write a short critique identifying one limitation and one improvement.",
      "skill": "Evaluation"
    }
  ],
  "investigation": {
    "question": "How can a reproducible investigation use entropy production to evaluate a physics claim?",
    "materials": [
      "Notebook",
      "Calculator or spreadsheet",
      "Clearly labelled sample data",
      "Versioned analysis notes"
    ],
    "method": [
      "Write a claim and prediction before analysis.",
      "Record data provenance, units and assumptions.",
      "Perform the analysis and retain intermediate results.",
      "Check the result with an independent method where possible.",
      "Publish a concise limitations statement."
    ],
    "safety": "Use safe classroom data and simulations. Do not use hazardous equipment or conduct experiments involving high voltage, high speed or uncontrolled heat."
  },
  "misconceptions": [
    {
      "claim": "A plausible explanation is automatically supported by evidence.",
      "correction": "A scientific claim must be tested against observations and alternative explanations."
    },
    {
      "claim": "A precise-looking number has no uncertainty.",
      "correction": "Precision of display is not the same as accuracy or certainty."
    },
    {
      "claim": "A model can settle every philosophical question about time.",
      "correction": "Physics constrains empirical claims; philosophical interpretation may require additional argument."
    }
  ],
  "exitTicket": [
    "What does entropy production contribute to scientific reasoning?",
    "What is one limitation of your example?",
    "What evidence should be collected next?"
  ]
};
