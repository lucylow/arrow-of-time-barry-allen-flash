export default {
  "id": 195,
  "title": "Nonlinear oscillators",
  "concepts": "Research Studio and Capstone",
  "summary": "Nonlinear restoring forces can make oscillation frequency depend on amplitude and produce complex dynamics.",
  "sourceNotes": "Final research studio. Nonlinear restoring forces can make oscillation frequency depend on amplitude and produce complex dynamics. Governing idea: x¨ + ω₀²x + βx³ = 0. The Duffing oscillator is a standard model for nonlinear vibration.",
  "mission": "Mission 195: Nonlinear oscillators",
  "reflection": "How could nonlinear oscillators strengthen or qualify a claim about the arrow of time?",
  "learningObjectives": [
    "Explain nonlinear oscillators with accurate terminology.",
    "Interpret the relationship x¨ + ω₀²x + βx³ = 0.",
    "Distinguish evidence, assumptions and inference."
  ],
  "keyTerms": [
    {
      "term": "Nonlinear oscillators",
      "meaning": "Nonlinear restoring forces can make oscillation frequency depend on amplitude and produce complex dynamics."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described range of plausible values or interpretations."
    },
    {
      "term": "Reproducibility",
      "meaning": "The ability for another person to repeat an analysis from documented materials."
    },
    {
      "term": "Falsifiability",
      "meaning": "A claim is testable when evidence could in principle show it to be wrong."
    }
  ],
  "workedExample": {
    "question": "The Duffing oscillator is a standard model for nonlinear vibration.",
    "method": [
      "State the question and define the system or hypothesis.",
      "Identify the data and assumptions required.",
      "Choose an appropriate method and explain why it fits.",
      "Carry out the analysis with units and transparent steps.",
      "Report uncertainty, limitations and a possible alternative explanation."
    ],
    "answer": "The Duffing oscillator is a standard model for nonlinear vibration.",
    "check": "What new observation would cause you to revise the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Define nonlinear oscillators and give one example.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Apply the principle x¨ + ω₀²x + βx³ = 0 to a small hypothetical dataset or scenario.",
      "skill": "Analysis"
    },
    {
      "difficulty": "Extension",
      "prompt": "Write a short critique identifying one limitation and one improvement.",
      "skill": "Evaluation"
    }
  ],
  "investigation": {
    "question": "How can a reproducible investigation use nonlinear oscillators to evaluate a physics claim?",
    "materials": [
      "Notebook",
      "Calculator or spreadsheet",
      "Clearly labelled sample data",
      "Versioned analysis notes"
    ],
    "method": [
      "Write a claim and prediction before analysis.",
      "Record data provenance, units and assumptions.",
      "Perform the analysis and retain intermediate results.",
      "Check the result with an independent method where possible.",
      "Publish a concise limitations statement."
    ],
    "safety": "Use safe classroom data and simulations. Do not use hazardous equipment or conduct experiments involving high voltage, high speed or uncontrolled heat."
  },
  "misconceptions": [
    {
      "claim": "A plausible explanation is automatically supported by evidence.",
      "correction": "A scientific claim must be tested against observations and alternative explanations."
    },
    {
      "claim": "A precise-looking number has no uncertainty.",
      "correction": "Precision of display is not the same as accuracy or certainty."
    },
    {
      "claim": "A model can settle every philosophical question about time.",
      "correction": "Physics constrains empirical claims; philosophical interpretation may require additional argument."
    }
  ],
  "exitTicket": [
    "What does nonlinear oscillators contribute to scientific reasoning?",
    "What is one limitation of your example?",
    "What evidence should be collected next?"
  ]
};
