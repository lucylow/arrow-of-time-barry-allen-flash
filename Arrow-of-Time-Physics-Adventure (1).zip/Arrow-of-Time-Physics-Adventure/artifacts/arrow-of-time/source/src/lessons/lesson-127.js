export default {
  "id": 127,
  "title": "Kirchhoff laws",
  "concepts": "Electricity and Magnetism",
  "summary": "Conservation of charge and energy lead to node and loop rules in circuits.",
  "sourceNotes": "Fields, circuits, induction and electromagnetic waves. Conservation of charge and energy lead to node and loop rules in circuits. The mathematical relationship is ΣIin = ΣIout; ΣΔV = 0. Interpret it only with its stated assumptions and appropriate units. A steady node with 2 A entering and one 0.5 A branch leaving has 1.5 A in the other branch.",
  "mission": "Mission 127: Kirchhoff laws",
  "reflection": "How does kirchhoff laws help Katniss distinguish a physical prediction from a time-machine story device?",
  "learningObjectives": [
    "Describe the central idea of kirchhoff laws using accurate physics language.",
    "Apply ΣIin = ΣIout; ΣΔV = 0 to a clearly defined physical situation.",
    "Identify assumptions, relevant evidence and at least one limitation of the model."
  ],
  "keyTerms": [
    {
      "term": "Kirchhoff laws",
      "meaning": "Conservation of charge and energy lead to node and loop rules in circuits."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated condition that defines the range where a simplified physical model is useful."
    },
    {
      "term": "Evidence",
      "meaning": "An observation or measurement that can be compared with a prediction."
    },
    {
      "term": "Limitation",
      "meaning": "A feature omitted or idealized that may matter in a more realistic system."
    }
  ],
  "workedExample": {
    "question": "Use kirchhoff laws to interpret this example: A steady node with 2 A entering and one 0.5 A branch leaving has 1.5 A in the other branch.",
    "method": [
      "Define the system and identify the relevant physical quantities.",
      "Write the governing relationship and define every symbol.",
      "Convert supplied values to consistent SI units.",
      "Substitute values and show intermediate steps.",
      "Check dimensions, limiting cases and physical plausibility."
    ],
    "answer": "A steady node with 2 A entering and one 0.5 A branch leaving has 1.5 A in the other branch.",
    "check": "Which assumption is most important, and how could you test whether it is reasonable?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain kirchhoff laws in your own words and identify its central quantity.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Create a labelled diagram or data table that could test this relationship: ΣIin = ΣIout; ΣΔV = 0.",
      "skill": "Scientific representation"
    },
    {
      "difficulty": "Extension",
      "prompt": "Change one model assumption. Predict which part of the result changes and justify your reasoning.",
      "skill": "Model evaluation"
    }
  ],
  "investigation": {
    "question": "What observable evidence could test a prediction involving kirchhoff laws?",
    "materials": [
      "Notebook and pencil",
      "Calculator or spreadsheet",
      "Timer or measuring tool where appropriate",
      "A safe classroom-scale demonstration or numerical model"
    ],
    "method": [
      "State a testable prediction before collecting data.",
      "Identify independent, dependent and controlled variables.",
      "Record repeated observations with units and uncertainty.",
      "Compare the data with the model and inspect residual differences.",
      "Explain limitations and propose one improvement."
    ],
    "safety": "Use only safe, low-energy classroom demonstrations. Do not use real bows, sharp arrows, high-speed projectiles, open flames, high voltage, boiling liquids or improvised pressure vessels."
  },
  "misconceptions": [
    {
      "claim": "A mathematical model is an exact description of every physical situation.",
      "correction": "Every model has assumptions and a domain of validity; compare it with observations."
    },
    {
      "claim": "A correlation automatically establishes a causal mechanism.",
      "correction": "Consider alternative explanations, controls and independent evidence."
    },
    {
      "claim": "A fictional time machine demonstrates that the proposed process is physically possible.",
      "correction": "Separate narrative devices from experimentally supported physics and mathematical models."
    }
  ],
  "exitTicket": [
    "State the central principle behind kirchhoff laws.",
    "Name one assumption in the worked example.",
    "Describe one measurement that could challenge the model."
  ]
};
