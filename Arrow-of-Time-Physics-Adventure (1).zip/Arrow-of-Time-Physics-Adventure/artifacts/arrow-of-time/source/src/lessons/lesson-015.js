export default {
  "id": 15,
  "title": "Power",
  "concepts": "Rate of energy transfer",
  "summary": "Power is work done or energy transferred per unit time: P = W/t. Its SI unit is the watt.",
  "sourceNotes": "You are Katniss Everdeen. Your bow is your most powerful weapon. But your greatest challenge isn't hitting a target... It's understanding TIME. Review: The Hunger Games (2012) — 3 Brothers Film The Best Text to Time Machine AI Generator (for Free) The New Rules of Goal Setting: Thriving in Uncertainty — Anne Trager | Potentializer Academy",
  "mission": "Mission 015: Power",
  "reflection": "What evidence would support your explanation, and what assumptions does your model make?",
  "learningObjectives": [
    "Define and explain rate of energy transfer using accurate physics language.",
    "Apply the central model in power to a clearly stated physical situation.",
    "Identify the assumptions, limitations and evidence relevant to the explanation."
  ],
  "keyTerms": [
    {
      "term": "Rate of energy transfer",
      "meaning": "Power is work done or energy transferred per unit time: P = W/t. Its SI unit is the watt."
    },
    {
      "term": "Model",
      "meaning": "A simplified representation used to explain observations and make testable predictions."
    },
    {
      "term": "System boundary",
      "meaning": "The chosen set of objects and surroundings included in an analysis."
    },
    {
      "term": "Assumption",
      "meaning": "A stated simplification that determines when a model is expected to work."
    }
  ],
  "workedExample": {
    "question": "How would you use rate of energy transfer to explain a new observation in the arena?",
    "method": [
      "Describe the system and choose a reference frame.",
      "List the known quantities and the quantity to be explained.",
      "Choose a physical model and write its governing relationship.",
      "Substitute values in consistent SI units when numerical data are supplied.",
      "Check units, limiting cases and whether the result is physically reasonable."
    ],
    "answer": "Power is work done or energy transferred per unit time: P = W/t. Its SI unit is the watt.",
    "check": "State one condition under which the model could stop being a good approximation."
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea of power in two or three sentences.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Create a labelled diagram of the system. Mark the relevant quantities, directions and system boundary.",
      "skill": "Representation"
    },
    {
      "difficulty": "Extension",
      "prompt": "Describe how the prediction changes if one assumption is removed. Justify your reasoning.",
      "skill": "Model evaluation"
    }
  ],
  "investigation": {
    "question": "What observable evidence could help investigate power?",
    "materials": [
      "Notebook and pencil",
      "Timer or stopwatch",
      "Ruler or measuring tape",
      "A safe everyday object or a simple computer model"
    ],
    "method": [
      "Write a prediction before collecting observations.",
      "Identify the independent, dependent and controlled variables where applicable.",
      "Repeat observations and record uncertainty or variation.",
      "Compare the observations with the model's prediction.",
      "Explain limitations and suggest one improvement."
    ],
    "safety": "Use only low-energy classroom demonstrations. Do not use a real bow, sharp arrows, high-speed projectiles, open flames, boiling liquids or improvised pressure vessels."
  },
  "misconceptions": [
    {
      "claim": "A simplified model describes every real situation exactly.",
      "correction": "Models are useful within stated assumptions; compare predictions with evidence and account for omitted effects."
    },
    {
      "claim": "A scientific explanation is the same thing as a fictional story device.",
      "correction": "The adventure provides context, while scientific claims must be supported by equations, observations and established theory."
    },
    {
      "claim": "A numerical answer is sufficient without units or reasoning.",
      "correction": "Show the method, use consistent units and interpret the result in context."
    }
  ],
  "exitTicket": [
    "What is the most important idea from this lesson?",
    "Which assumption matters most to the model?",
    "What new observation would make you revise your explanation?"
  ]
};
