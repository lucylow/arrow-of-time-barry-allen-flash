export default {
  "id": 56,
  "title": "Wormholes",
  "concepts": "Hypothetical spacetime connections",
  "summary": "Wormholes are mathematical geometries connecting distant spacetime regions. Their existence in nature has not been established.",
  "sourceNotes": "Wormholes, causality and time-travel paradoxes. Quantum physics and cosmology. Experiments, diagrams, challenges and answer keys. The central storyline will follow Katniss as she investigates a collapsing timeline, with each adventure introducing real physics. The most important educational distinction: readers should finish understanding what physics actually permits, what scientists have experimentally demonstrated, and what remains science fiction. 🏹 Let's build the actual 100 pages of educational content, not just an outline. I'll develop it as a substantial physics learning book, with Katniss's adventure woven throughout. I can't currently generate the downloadable PDF because the data analysis capability is temporarily unavailable. However, I can write the manuscript directly here, in installments, without waiting for that capability.",
  "mission": "Mission 056: Wormholes",
  "reflection": "What evidence would support your explanation, and what assumptions does your model make?",
  "learningObjectives": [
    "Define and explain hypothetical spacetime connections using accurate physics language.",
    "Apply the central model in wormholes to a clearly stated physical situation.",
    "Identify the assumptions, limitations and evidence relevant to the explanation."
  ],
  "keyTerms": [
    {
      "term": "Hypothetical spacetime connections",
      "meaning": "Wormholes are mathematical geometries connecting distant spacetime regions. Their existence in nature has not been established."
    },
    {
      "term": "Model",
      "meaning": "A simplified representation used to explain observations and make testable predictions."
    },
    {
      "term": "System boundary",
      "meaning": "The chosen set of objects and surroundings included in an analysis."
    },
    {
      "term": "Assumption",
      "meaning": "A stated simplification that determines when a model is expected to work."
    }
  ],
  "workedExample": {
    "question": "How would you use hypothetical spacetime connections to explain a new observation in the arena?",
    "method": [
      "Describe the system and choose a reference frame.",
      "List the known quantities and the quantity to be explained.",
      "Choose a physical model and write its governing relationship.",
      "Substitute values in consistent SI units when numerical data are supplied.",
      "Check units, limiting cases and whether the result is physically reasonable."
    ],
    "answer": "Wormholes are mathematical geometries connecting distant spacetime regions. Their existence in nature has not been established.",
    "check": "State one condition under which the model could stop being a good approximation."
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain the central idea of wormholes in two or three sentences.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Create a labelled diagram of the system. Mark the relevant quantities, directions and system boundary.",
      "skill": "Representation"
    },
    {
      "difficulty": "Extension",
      "prompt": "Describe how the prediction changes if one assumption is removed. Justify your reasoning.",
      "skill": "Model evaluation"
    }
  ],
  "investigation": {
    "question": "What observable evidence could help investigate wormholes?",
    "materials": [
      "Notebook and pencil",
      "Timer or stopwatch",
      "Ruler or measuring tape",
      "A safe everyday object or a simple computer model"
    ],
    "method": [
      "Write a prediction before collecting observations.",
      "Identify the independent, dependent and controlled variables where applicable.",
      "Repeat observations and record uncertainty or variation.",
      "Compare the observations with the model's prediction.",
      "Explain limitations and suggest one improvement."
    ],
    "safety": "Use only low-energy classroom demonstrations. Do not use a real bow, sharp arrows, high-speed projectiles, open flames, boiling liquids or improvised pressure vessels."
  },
  "misconceptions": [
    {
      "claim": "A simplified model describes every real situation exactly.",
      "correction": "Models are useful within stated assumptions; compare predictions with evidence and account for omitted effects."
    },
    {
      "claim": "A scientific explanation is the same thing as a fictional story device.",
      "correction": "The adventure provides context, while scientific claims must be supported by equations, observations and established theory."
    },
    {
      "claim": "A numerical answer is sufficient without units or reasoning.",
      "correction": "Show the method, use consistent units and interpret the result in context."
    }
  ],
  "exitTicket": [
    "What is the most important idea from this lesson?",
    "Which assumption matters most to the model?",
    "What new observation would make you revise your explanation?"
  ]
};
