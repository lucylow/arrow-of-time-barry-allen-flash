export default {
  "id": 191,
  "title": "Bayesian reasoning",
  "concepts": "Research Studio and Capstone",
  "summary": "Bayesian inference updates the probability assigned to a hypothesis when new evidence is observed.",
  "sourceNotes": "Final research studio. Bayesian inference updates the probability assigned to a hypothesis when new evidence is observed. Governing idea: P(H|E)=P(E|H)P(H)/P(E). A test result changes a prior probability according to the test sensitivity and false-positive rate.",
  "mission": "Mission 191: Bayesian reasoning",
  "reflection": "How could bayesian reasoning strengthen or qualify a claim about the arrow of time?",
  "learningObjectives": [
    "Explain bayesian reasoning with accurate terminology.",
    "Interpret the relationship P(H|E)=P(E|H)P(H)/P(E).",
    "Distinguish evidence, assumptions and inference."
  ],
  "keyTerms": [
    {
      "term": "Bayesian reasoning",
      "meaning": "Bayesian inference updates the probability assigned to a hypothesis when new evidence is observed."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described range of plausible values or interpretations."
    },
    {
      "term": "Reproducibility",
      "meaning": "The ability for another person to repeat an analysis from documented materials."
    },
    {
      "term": "Falsifiability",
      "meaning": "A claim is testable when evidence could in principle show it to be wrong."
    }
  ],
  "workedExample": {
    "question": "A test result changes a prior probability according to the test sensitivity and false-positive rate.",
    "method": [
      "State the question and define the system or hypothesis.",
      "Identify the data and assumptions required.",
      "Choose an appropriate method and explain why it fits.",
      "Carry out the analysis with units and transparent steps.",
      "Report uncertainty, limitations and a possible alternative explanation."
    ],
    "answer": "A test result changes a prior probability according to the test sensitivity and false-positive rate.",
    "check": "What new observation would cause you to revise the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Define bayesian reasoning and give one example.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Apply the principle P(H|E)=P(E|H)P(H)/P(E) to a small hypothetical dataset or scenario.",
      "skill": "Analysis"
    },
    {
      "difficulty": "Extension",
      "prompt": "Write a short critique identifying one limitation and one improvement.",
      "skill": "Evaluation"
    }
  ],
  "investigation": {
    "question": "How can a reproducible investigation use bayesian reasoning to evaluate a physics claim?",
    "materials": [
      "Notebook",
      "Calculator or spreadsheet",
      "Clearly labelled sample data",
      "Versioned analysis notes"
    ],
    "method": [
      "Write a claim and prediction before analysis.",
      "Record data provenance, units and assumptions.",
      "Perform the analysis and retain intermediate results.",
      "Check the result with an independent method where possible.",
      "Publish a concise limitations statement."
    ],
    "safety": "Use safe classroom data and simulations. Do not use hazardous equipment or conduct experiments involving high voltage, high speed or uncontrolled heat."
  },
  "misconceptions": [
    {
      "claim": "A plausible explanation is automatically supported by evidence.",
      "correction": "A scientific claim must be tested against observations and alternative explanations."
    },
    {
      "claim": "A precise-looking number has no uncertainty.",
      "correction": "Precision of display is not the same as accuracy or certainty."
    },
    {
      "claim": "A model can settle every philosophical question about time.",
      "correction": "Physics constrains empirical claims; philosophical interpretation may require additional argument."
    }
  ],
  "exitTicket": [
    "What does bayesian reasoning contribute to scientific reasoning?",
    "What is one limitation of your example?",
    "What evidence should be collected next?"
  ]
};
