export default {
  "id": 131,
  "title": "Temperature and thermal equilibrium",
  "concepts": "Thermal Physics",
  "summary": "Temperature determines the direction of net thermal energy transfer between systems.",
  "sourceNotes": "Heat transfer, kinetic theory and thermodynamic potentials. Temperature determines the direction of net thermal energy transfer between systems. The mathematical relationship is Tₐ = Tᵦ at equilibrium. Interpret it only with its stated assumptions and appropriate units. A thermometer reaches thermal equilibrium with the object it measures.",
  "mission": "Mission 131: Temperature and thermal equilibrium",
  "reflection": "How does temperature and thermal equilibrium help Katniss distinguish a physical prediction from a time-machine story device?",
  "learningObjectives": [
    "Describe the central idea of temperature and thermal equilibrium using accurate physics language.",
    "Apply Tₐ = Tᵦ at equilibrium to a clearly defined physical situation.",
    "Identify assumptions, relevant evidence and at least one limitation of the model."
  ],
  "keyTerms": [
    {
      "term": "Temperature and thermal equilibrium",
      "meaning": "Temperature determines the direction of net thermal energy transfer between systems."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated condition that defines the range where a simplified physical model is useful."
    },
    {
      "term": "Evidence",
      "meaning": "An observation or measurement that can be compared with a prediction."
    },
    {
      "term": "Limitation",
      "meaning": "A feature omitted or idealized that may matter in a more realistic system."
    }
  ],
  "workedExample": {
    "question": "Use temperature and thermal equilibrium to interpret this example: A thermometer reaches thermal equilibrium with the object it measures.",
    "method": [
      "Define the system and identify the relevant physical quantities.",
      "Write the governing relationship and define every symbol.",
      "Convert supplied values to consistent SI units.",
      "Substitute values and show intermediate steps.",
      "Check dimensions, limiting cases and physical plausibility."
    ],
    "answer": "A thermometer reaches thermal equilibrium with the object it measures.",
    "check": "Which assumption is most important, and how could you test whether it is reasonable?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain temperature and thermal equilibrium in your own words and identify its central quantity.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Create a labelled diagram or data table that could test this relationship: Tₐ = Tᵦ at equilibrium.",
      "skill": "Scientific representation"
    },
    {
      "difficulty": "Extension",
      "prompt": "Change one model assumption. Predict which part of the result changes and justify your reasoning.",
      "skill": "Model evaluation"
    }
  ],
  "investigation": {
    "question": "What observable evidence could test a prediction involving temperature and thermal equilibrium?",
    "materials": [
      "Notebook and pencil",
      "Calculator or spreadsheet",
      "Timer or measuring tool where appropriate",
      "A safe classroom-scale demonstration or numerical model"
    ],
    "method": [
      "State a testable prediction before collecting data.",
      "Identify independent, dependent and controlled variables.",
      "Record repeated observations with units and uncertainty.",
      "Compare the data with the model and inspect residual differences.",
      "Explain limitations and propose one improvement."
    ],
    "safety": "Use only safe, low-energy classroom demonstrations. Do not use real bows, sharp arrows, high-speed projectiles, open flames, high voltage, boiling liquids or improvised pressure vessels."
  },
  "misconceptions": [
    {
      "claim": "A mathematical model is an exact description of every physical situation.",
      "correction": "Every model has assumptions and a domain of validity; compare it with observations."
    },
    {
      "claim": "A correlation automatically establishes a causal mechanism.",
      "correction": "Consider alternative explanations, controls and independent evidence."
    },
    {
      "claim": "A fictional time machine demonstrates that the proposed process is physically possible.",
      "correction": "Separate narrative devices from experimentally supported physics and mathematical models."
    }
  ],
  "exitTicket": [
    "State the central principle behind temperature and thermal equilibrium.",
    "Name one assumption in the worked example.",
    "Describe one measurement that could challenge the model."
  ]
};
