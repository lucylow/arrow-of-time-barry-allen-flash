export default {
  "id": 197,
  "title": "Causal inference",
  "concepts": "Research Studio and Capstone",
  "summary": "Causal claims require a design or model that separates cause from confounding association.",
  "sourceNotes": "Final research studio. Causal claims require a design or model that separates cause from confounding association. Governing idea: intervention ≠ observation. A controlled intervention can test whether changing one variable changes an outcome.",
  "mission": "Mission 197: Causal inference",
  "reflection": "How could causal inference strengthen or qualify a claim about the arrow of time?",
  "learningObjectives": [
    "Explain causal inference with accurate terminology.",
    "Interpret the relationship intervention ≠ observation.",
    "Distinguish evidence, assumptions and inference."
  ],
  "keyTerms": [
    {
      "term": "Causal inference",
      "meaning": "Causal claims require a design or model that separates cause from confounding association."
    },
    {
      "term": "Uncertainty",
      "meaning": "A quantified or described range of plausible values or interpretations."
    },
    {
      "term": "Reproducibility",
      "meaning": "The ability for another person to repeat an analysis from documented materials."
    },
    {
      "term": "Falsifiability",
      "meaning": "A claim is testable when evidence could in principle show it to be wrong."
    }
  ],
  "workedExample": {
    "question": "A controlled intervention can test whether changing one variable changes an outcome.",
    "method": [
      "State the question and define the system or hypothesis.",
      "Identify the data and assumptions required.",
      "Choose an appropriate method and explain why it fits.",
      "Carry out the analysis with units and transparent steps.",
      "Report uncertainty, limitations and a possible alternative explanation."
    ],
    "answer": "A controlled intervention can test whether changing one variable changes an outcome.",
    "check": "What new observation would cause you to revise the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Define causal inference and give one example.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Apply the principle intervention ≠ observation to a small hypothetical dataset or scenario.",
      "skill": "Analysis"
    },
    {
      "difficulty": "Extension",
      "prompt": "Write a short critique identifying one limitation and one improvement.",
      "skill": "Evaluation"
    }
  ],
  "investigation": {
    "question": "How can a reproducible investigation use causal inference to evaluate a physics claim?",
    "materials": [
      "Notebook",
      "Calculator or spreadsheet",
      "Clearly labelled sample data",
      "Versioned analysis notes"
    ],
    "method": [
      "Write a claim and prediction before analysis.",
      "Record data provenance, units and assumptions.",
      "Perform the analysis and retain intermediate results.",
      "Check the result with an independent method where possible.",
      "Publish a concise limitations statement."
    ],
    "safety": "Use safe classroom data and simulations. Do not use hazardous equipment or conduct experiments involving high voltage, high speed or uncontrolled heat."
  },
  "misconceptions": [
    {
      "claim": "A plausible explanation is automatically supported by evidence.",
      "correction": "A scientific claim must be tested against observations and alternative explanations."
    },
    {
      "claim": "A precise-looking number has no uncertainty.",
      "correction": "Precision of display is not the same as accuracy or certainty."
    },
    {
      "claim": "A model can settle every philosophical question about time.",
      "correction": "Physics constrains empirical claims; philosophical interpretation may require additional argument."
    }
  ],
  "exitTicket": [
    "What does causal inference contribute to scientific reasoning?",
    "What is one limitation of your example?",
    "What evidence should be collected next?"
  ]
};
