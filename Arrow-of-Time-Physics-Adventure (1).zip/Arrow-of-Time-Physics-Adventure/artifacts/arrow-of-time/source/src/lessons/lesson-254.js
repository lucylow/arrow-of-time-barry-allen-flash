export default {
  "id": 254,
  "title": "Fission",
  "concepts": "Splitting heavy nuclei",
  "summary": "Nuclear fission releases energy when heavy nuclei split into fragments with greater total binding energy.",
  "sourceNotes": "Volume III, frontier physics sequence. Nuclear fission releases energy when heavy nuclei split into fragments with greater total binding energy. The focus is on definitions, model assumptions, evidence and limits of interpretation.",
  "mission": "Mission 254: investigate Fission",
  "reflection": "What does fission reveal about physical change, measurement or the arrow of time?",
  "learningObjectives": [
    "Describe fission using accurate physics terminology.",
    "Explain how splitting heavy nuclei connects to conservation laws, measurement or the evolution of a physical system.",
    "State the assumptions and limits of a model used to interpret evidence."
  ],
  "keyTerms": [
    {
      "term": "Fission",
      "meaning": "Nuclear fission releases energy when heavy nuclei split into fragments with greater total binding energy."
    },
    {
      "term": "System boundary",
      "meaning": "The chosen separation between the physical system and its surroundings."
    },
    {
      "term": "Model assumption",
      "meaning": "A simplifying condition that makes a calculation or explanation possible."
    },
    {
      "term": "Uncertainty",
      "meaning": "A range or distribution expressing limitations in measured or inferred quantities."
    }
  ],
  "workedExample": {
    "question": "Consider a system involving fission. Identify its boundary, relevant variables and governing assumptions before selecting an equation.",
    "method": [
      "Define the system and the physical quantity being investigated.",
      "List known values, units, boundary conditions and assumptions.",
      "Choose a governing principle and explain why it applies.",
      "Calculate or reason step by step, checking units and limiting cases.",
      "Interpret the result and identify at least one limitation."
    ],
    "answer": "Nuclear fission releases energy when heavy nuclei split into fragments with greater total binding energy.",
    "check": "Which assumption, if changed, would most affect the conclusion?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Define fission and describe one physical example.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Apply splitting heavy nuclei to a worked scenario. State variables, units and assumptions.",
      "skill": "Quantitative and qualitative reasoning"
    },
    {
      "difficulty": "Extension",
      "prompt": "Compare two models or explanations of fission. Identify what evidence would distinguish them.",
      "skill": "Evaluation and synthesis"
    }
  ],
  "investigation": {
    "question": "How would you test a claim about fission using observations or a clearly stated model?",
    "materials": [
      "Notebook or digital lab journal",
      "Calculator or spreadsheet",
      "Clearly labelled sample data or a safe simulation",
      "Graph paper or plotting software"
    ],
    "method": [
      "Write a testable question and prediction.",
      "Define the system, variables and measurement procedure.",
      "Collect or generate a small dataset and record units.",
      "Graph the relevant quantities and compare with a model.",
      "Discuss uncertainty, alternative explanations and a next experiment."
    ],
    "safety": "Use simulations or safe classroom demonstrations. Do not work with hazardous radiation, high voltage, pressure vessels, lasers, extreme temperatures or high-speed machinery."
  },
  "misconceptions": [
    {
      "claim": "A single equation completely describes every situation involving fission.",
      "correction": "Equations apply under stated assumptions; real systems may require additional effects or a different model."
    },
    {
      "claim": "A model prediction is the same thing as a direct observation.",
      "correction": "Predictions are consequences of assumptions; observations are measurements with uncertainty."
    },
    {
      "claim": "A small numerical uncertainty guarantees that a model is correct.",
      "correction": "Measurement precision does not eliminate systematic error, missing physics or model bias."
    }
  ],
  "exitTicket": [
    "State the central idea of fission in one sentence.",
    "Name one assumption in the model you used.",
    "What additional evidence would strengthen your conclusion?"
  ]
};
