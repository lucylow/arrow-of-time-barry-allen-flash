export default {
  "id": 182,
  "title": "Significant figures",
  "concepts": "Research Studio and Capstone",
  "summary": "Reported digits should reflect the precision of the measurement and calculation.",
  "sourceNotes": "Uncertainty, modelling, reproducibility and integrated investigations. Reported digits should reflect the precision of the measurement and calculation. The mathematical relationship is precision follows inputs. Interpret it only with its stated assumptions and appropriate units. A calculator’s many digits do not guarantee measurement accuracy.",
  "mission": "Mission 182: Significant figures",
  "reflection": "How does significant figures help Katniss distinguish a physical prediction from a time-machine story device?",
  "learningObjectives": [
    "Describe the central idea of significant figures using accurate physics language.",
    "Apply precision follows inputs to a clearly defined physical situation.",
    "Identify assumptions, relevant evidence and at least one limitation of the model."
  ],
  "keyTerms": [
    {
      "term": "Significant figures",
      "meaning": "Reported digits should reflect the precision of the measurement and calculation."
    },
    {
      "term": "Model assumption",
      "meaning": "A stated condition that defines the range where a simplified physical model is useful."
    },
    {
      "term": "Evidence",
      "meaning": "An observation or measurement that can be compared with a prediction."
    },
    {
      "term": "Limitation",
      "meaning": "A feature omitted or idealized that may matter in a more realistic system."
    }
  ],
  "workedExample": {
    "question": "Use significant figures to interpret this example: A calculator’s many digits do not guarantee measurement accuracy.",
    "method": [
      "Define the system and identify the relevant physical quantities.",
      "Write the governing relationship and define every symbol.",
      "Convert supplied values to consistent SI units.",
      "Substitute values and show intermediate steps.",
      "Check dimensions, limiting cases and physical plausibility."
    ],
    "answer": "A calculator’s many digits do not guarantee measurement accuracy.",
    "check": "Which assumption is most important, and how could you test whether it is reasonable?"
  },
  "practice": [
    {
      "difficulty": "Foundation",
      "prompt": "Explain significant figures in your own words and identify its central quantity.",
      "skill": "Conceptual understanding"
    },
    {
      "difficulty": "Application",
      "prompt": "Create a labelled diagram or data table that could test this relationship: precision follows inputs.",
      "skill": "Scientific representation"
    },
    {
      "difficulty": "Extension",
      "prompt": "Change one model assumption. Predict which part of the result changes and justify your reasoning.",
      "skill": "Model evaluation"
    }
  ],
  "investigation": {
    "question": "What observable evidence could test a prediction involving significant figures?",
    "materials": [
      "Notebook and pencil",
      "Calculator or spreadsheet",
      "Timer or measuring tool where appropriate",
      "A safe classroom-scale demonstration or numerical model"
    ],
    "method": [
      "State a testable prediction before collecting data.",
      "Identify independent, dependent and controlled variables.",
      "Record repeated observations with units and uncertainty.",
      "Compare the data with the model and inspect residual differences.",
      "Explain limitations and propose one improvement."
    ],
    "safety": "Use only safe, low-energy classroom demonstrations. Do not use real bows, sharp arrows, high-speed projectiles, open flames, high voltage, boiling liquids or improvised pressure vessels."
  },
  "misconceptions": [
    {
      "claim": "A mathematical model is an exact description of every physical situation.",
      "correction": "Every model has assumptions and a domain of validity; compare it with observations."
    },
    {
      "claim": "A correlation automatically establishes a causal mechanism.",
      "correction": "Consider alternative explanations, controls and independent evidence."
    },
    {
      "claim": "A fictional time machine demonstrates that the proposed process is physically possible.",
      "correction": "Separate narrative devices from experimentally supported physics and mathematical models."
    }
  ],
  "exitTicket": [
    "State the central principle behind significant figures.",
    "Name one assumption in the worked example.",
    "Describe one measurement that could challenge the model."
  ]
};
