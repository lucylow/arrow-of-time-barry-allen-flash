export const questions = [
  {
    "level": 1,
    "title": "The Arrow That Never Comes Back",
    "story": "Katniss fires an arrow. It hits a target and falls. Why doesn't it spontaneously reverse its journey?",
    "options": [
      "Gravity only works forwards in time.",
      "The arrow transfers organized mechanical energy to air, sound and heat; the reverse macroscopic event is overwhelmingly unlikely.",
      "Arrows are naturally afraid of going backwards."
    ],
    "correct": 1,
    "explain": "Drag and impact disperse organized motion into microscopic degrees of freedom. Energy is conserved, while the total entropy of the isolated system does not spontaneously decrease."
  },
  {
    "level": 2,
    "title": "The Time-Travel Portal",
    "story": "A glass falls from a table and smashes. Can Katniss reverse the event?",
    "options": [
      "Yes, broken glass naturally reassembles itself.",
      "No. Reversing every particle's motion with extraordinary precision would be required; the reverse event is overwhelmingly unlikely.",
      "Yes, because time always runs backwards in a time machine."
    ],
    "correct": 1,
    "explain": "The microscopic dynamics may allow reversed trajectories in idealized settings, but the coordinated state needed for all fragments, sound and heat to reassemble is fantastically improbable."
  },
  {
    "level": 3,
    "title": "The Impossible Shot",
    "story": "An arrow is fired horizontally at 20 m/s and stays in flight for 2 s. Ignore air resistance. How far does it travel horizontally?",
    "options": [
      "10 metres",
      "20 metres",
      "40 metres",
      "80 metres"
    ],
    "correct": 2,
    "explain": "Horizontal displacement is x = vₓt = 20 m/s × 2 s = 40 m."
  },
  {
    "level": 4,
    "title": "The Reverse Universe",
    "story": "Rain rises, smoke returns to a candle and broken glass reconstructs. What does this suggest?",
    "options": [
      "Many fundamental microscopic laws are approximately time-reversal symmetric, while everyday thermodynamic processes have a preferred direction.",
      "All physics laws require time to move forwards.",
      "Time reversal is the same as travelling to the future."
    ],
    "correct": 0,
    "explain": "Idealized microscopic equations can often be time-reversal symmetric, but macroscopic processes are governed by overwhelmingly probable entropy-increasing evolution. Some fundamental interactions do violate time-reversal symmetry."
  },
  {
    "level": 5,
    "title": "The Final Shot — Save the Timeline",
    "story": "President Snow's machine is active. Explain why we remember the past but not the future.",
    "options": [
      "Our brains are physically arranged to remember the future.",
      "Memory formation involves physical processes connected to the thermodynamic arrow of time.",
      "The future hasn't been invented yet."
    ],
    "correct": 1,
    "explain": "Forming and storing memories involves physical information-processing processes, energy use and entropy production. Records correlate with the past, not a known future."
  }
];
