# The Arrow of Time — Physics Adventure Web App

An original, responsive educational web app built from the uploaded **TODO-ARROW OF TIME KATNISS.docx** manuscript.

## Included
- 300 individual lesson modules (`src/lessons/lesson-001.js` … `lesson-300.js`)
- A 5-challenge quiz adapted from the source's opening game
- Persistent local progress, notes, scores and theme preference
- 18 interactive physics models: three core simulators, ten advanced tools and five frontier models
- Searchable/filterable curriculum is included in the lesson data and learning path
- Responsive desktop and mobile layouts

## Run locally
1. Install Node.js 18 or newer.
2. In this folder run `npm install`.
3. Run `npm run dev`.
4. Open the local address printed by Vite.

## Build
`npm run build` creates the production bundle in `dist/`.

## Notes
- Progress is stored in the browser's localStorage on the current device.
- Physics simulators state their assumptions and are intended for learning.
- Time travel into the past, traversable wormholes and controllable time machines are not presented as established technology.
- The source manuscript contains repeated drafts and evolving outlines. The app organizes its central topics into a 300-lesson sequence and includes source-aligned introductory quiz questions.
- Expansion notes: `EXPANSION-PACK-101-200.md` and `EXPANSION-PACK-201-300.md`.
