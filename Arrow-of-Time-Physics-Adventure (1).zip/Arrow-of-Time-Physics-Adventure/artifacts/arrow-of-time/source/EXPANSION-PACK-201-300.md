# Arrow of Time — Expansion Pack 201–300

This third volume extends the existing 200-lesson application to **300 individually addressable lessons**. It preserves lessons 001–200 and appends 100 new modules under `src/lessons/`.

## Curriculum map
- 201–210 Fluids and oscillations
- 211–220 Acoustics, waves and optics
- 221–230 Electricity and magnetism
- 231–240 Thermal physics and statistical mechanics
- 241–250 Quantum mechanics
- 251–260 Nuclear and particle physics
- 261–270 Relativity and compact objects
- 271–280 Stellar and observational cosmology
- 281–290 Nonlinear systems, networks and information
- 291–300 Computation, inference, experimental design and synthesis

Each lesson includes learning objectives, key terms, a worked example, three practice tiers, an investigation with safety notes, misconception corrections and exit tickets.

## New interactive workbench
`src/FrontierLab.jsx` adds hydrostatic pressure/buoyancy, resonant air columns, radioactive decay, thermal radiation and Bayesian evidence updating. The models state their assumptions in the interface.

## Integration
The new lessons are imported into `src/lessons.js`, and the Frontier Physics Workbench is integrated into the existing Physics Lab. Progress categories now include lessons 201–300.

## Run
From the project root: `npm install`, then `npm run dev`. Build with `npm run build`.

## Scientific scope
These are educational models. They distinguish idealized equations from real-world systems and do not present speculative time travel as established technology.
