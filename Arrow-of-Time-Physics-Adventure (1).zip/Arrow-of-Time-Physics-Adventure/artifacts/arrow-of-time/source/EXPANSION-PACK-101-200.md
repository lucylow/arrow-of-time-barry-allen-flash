# Arrow of Time — Expansion Pack 101–200

This pack extends the original 100-lesson app to 200 lessons. It adds 100 separately addressable lesson modules, each with objectives, key terms, a worked example, three practice tiers, a safe investigation, misconception checks and exit tickets.

## New curriculum
- 101–110 Advanced mechanics
- 111–120 Waves and optics
- 121–130 Electricity and magnetism
- 131–140 Thermal physics
- 141–150 Quantum foundations
- 151–160 Relativity and gravitation
- 161–170 Astronomy and cosmology
- 171–180 Complex systems and information
- 181–200 Research studio and capstone

## New interactive tools
The Advanced Physics Instrument Deck adds models for Schwarzschild radius, Newtonian surface gravity, entropy transfer, photon energy, radioactive decay, two-wave interference, classical Doppler shift, gravitational clock rate, kinetic energy and circular orbital speed. Each model states its assumptions in the interface.

## Run
`npm install` then `npm run dev`. Build with `npm run build`.

## Scope note
The new lessons are original instructional expansions aligned with the manuscript's physics themes. They distinguish established equations and evidence from fictional time-travel plot elements.
