// @ts-expect-error The supplied adventure source is JavaScript/JSX and is bundled directly by Vite.
import Adventure from '../source/src/App.jsx';
import '../source/src/styles.css';

function App() {
  return <Adventure />;
}

export default App;
